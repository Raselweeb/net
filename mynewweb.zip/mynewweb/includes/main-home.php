

<!DOCTYPE html>
<!--[if lt IE 7 ]>
<html class="ie ie6" lang="en"> <![endif]-->
<!--[if IE 7 ]>
<html class="ie ie7" lang="en"> <![endif]-->
<!--[if IE 8 ]>
<html class="ie ie8" lang="en"> <![endif]-->
<!--[if (gte IE 9)|!(IE)]><!-->
<html lang="en">
<!--<![endif]-->
<meta charset="utf-8">

<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    

    <!-- userway accessibility start -->
    <!-- <script type="text/javascript">
            var _userway_config = {
            account: "xyS2BuGIbM"
            };
        </script>
        <script type="text/javascript" src="https://cdn.userway.org/widget.js"></script> -->
    <!-- userway accessibility end -->

    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="shortcut icon" href="/misc/favicon.ico" type="image/x-icon" />

    <!-- Mobile Specific Metas
    ================================================== -->

    <script type="text/javascript">
        var switchTo5x = true;
    </script>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- required files for accesssibility by tt -->
    <link rel="stylesheet" href="https://bteb.gov.bd//themes/responsive_npf/templates/ministry/accessibility.css">
    <script src="https://bteb.gov.bd//themes/responsive_npf/js/jquery-accessibleMegaMenu.js"></script>

    <!--<meta http-equiv="X-Frame-Options" content="deny">-->


    <title>
        Khan Online Portal | | খাঁন অনলাইন পোর্টাল   </title>
    <!-- ======================= tt title End ======================== -->
    <!-- ======================= tt Description start ======================== -->
        <meta name="description" content=" MOHAMMAD TOFAZZEL HOSSAIN MIAH Principal Secretary to HPM Prime Minister’s Office, Dhaka, Bangladesh Telephone: +88-02-55029453 Email :journey.thm@gmail.">
    <!-- ======================= tt Description End ======================== -->


    <!-- Social Sharing-->
    <!-- for Facebook -->
    <meta property="og:title" content="#" />
    <meta property="og:type" content="website" />
    <meta property="og:image" content="https://bteb.gov.bd//themes/responsive_npf/img/200X200.png" />
    <meta property="og:url" content="http%3A%2F%2Fpmo.gov.bd%2Fsite%2Fbiography%2F2e8145ab-3df7-404d-8bb9-ae38daa68eeb" />
    <meta property="og:description" content=" MOHAMMAD TOFAZZEL HOSSAIN MIAH Principal Secretary to HPM Prime Minister’s Office, Dhaka, Bangladesh Telephone: +88-02-55029453 Email :journey.thm@gmail.com;psecy@pmo.gov.bd Website : www.pmo.gov.bd Mohammad Tofazzel Hossain Miah serves as the Principal Secretary to the Hon’ble Prime Mi" />

    <!-- for Twitter -->
    <meta name="twitter:card" content="summary" />
    <meta name="twitter:title" content="#" />
    <meta name="twitter:description" content=" MOHAMMAD TOFAZZEL HOSSAIN MIAH Principal Secretary to HPM Prime Minister’s Office, Dhaka, Bangladesh Telephone: +88-02-55029453 Email :journey.thm@gmail.com;psecy@pmo.gov.bd Website : www.pmo.gov.bd Mohammad Tofazzel Hossain Miah serves as the Principal Secretary to the Hon’ble Prime Mi" />
    <meta name="twitter:image" content="https://bteb.gov.bd//themes/responsive_npf/img/400X400.png" />


    


    
        <link type="text/css" rel="stylesheet" media="all" href="https://bteb.gov.bd//themes/responsive_npf/stylesheets/base.css" /><link type="text/css" rel="stylesheet" media="all" href="https://bteb.gov.bd//themes/responsive_npf/stylesheets/skeleton.css" /><link type="text/css" rel="stylesheet" media="all" href="https://bteb.gov.bd//themes/responsive_npf/stylesheets/style.css" /><link type="text/css" rel="stylesheet" media="all" href="https://bteb.gov.bd//themes/responsive_npf/stylesheets/meganizr.css" /><link type="text/css" rel="stylesheet" media="all" href="https://bteb.gov.bd//themes/responsive_npf/stylesheets/demo.css" /><link type="text/css" rel="stylesheet" media="all" href="https://bteb.gov.bd//npfadmin/public/css/flaticon/flaticon.css" /><link type="text/css" rel="stylesheet" media="all" href="themes/responsive_npf/templates/ministry/style.css" />
    <script type="text/javascript" src="//ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>
    <script>
        $(document).ready(function() {

            var fullText = $('.updateText').text();
            var fullText1 = fullText.substring(0, fullText.indexOf(":"));
            var fullText2 = fullText.substring(fullText.indexOf(":") + 1);
            var dateText = fullText2;
            var mapObj = {
                st: "",
                nd: "",
                rd: "",
                th: "",
            };
            dateText = dateText.replace(/st|nd|rd|th/g, function(matched) {
                return mapObj[matched];
            });
            var resultDate = fullText1 + ':' + dateText;
            $('.updateText').text(resultDate);
            if ($('input#email').is(":visible")) {
                $('input#email').attr('type', 'email');
            }
        });
    </script>

    <script>
        //jq160 = jQuery.noConflict( true );
    </script>
        <!-- for share option -->
    <link href="https://fonts.googleapis.com/css2?family=Hind+Siliguri:wght@600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://bteb.gov.bd//themes/responsive_npf/stylesheets/responsiveslides.css">
    <link rel="stylesheet" href="https://bteb.gov.bd//themes/responsive_npf/templates/ministry/responsive.css">
    <script src="https://bteb.gov.bd//themes/responsive_npf/js/responsiveslides.min.js"></script>
    <script src="https://bteb.gov.bd//themes/responsive_npf/js/jquery.vticker.js" type="text/javascript"></script>

    <script src="https://bteb.gov.bd//themes/responsive_npf/js/domain_selector.js" type="text/javascript"></script>
    <script src="https://bteb.gov.bd//themes/responsive_npf/js/utils.js" type="text/javascript"></script>
    <script src="https://bteb.gov.bd//themes/responsive_npf/js/jquery.media.js" type="text/javascript"></script>


    <meta property="og:image" content="" />

    <!-- Matomo -->
    <!-- <script type="text/javascript">
                      var _paq = window._paq || [];
                      /* tracker methods like "setCustomDimension" should be called before "trackPageView" */
                      _paq.push(['trackPageView']);
                      _paq.push(['enableLinkTracking']);
                      (function() {
                        var u="//localhost/analytics/matomo/";
                        _paq.push(['setTrackerUrl', u+'matomo.php']);
                        _paq.push(['setSiteId', '1']);
                        var d=document, g=d.createElement('script'), s=d.getElementsByTagName('script')[0];
                        g.type='text/javascript'; g.async=true; g.defer=true; g.src=u+'matomo.js'; s.parentNode.insertBefore(g,s);
                      })();
                    </script> -->
    <!-- End Matomo Code -->

    <!-- custom accessibility start -->
    <link rel="stylesheet" href="https://bteb.gov.bd//accessibility/css/asb.css">
    <script src="/accessibility/js/asb.js" type="text/javascript"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.9.0/css/all.min.css" />
    <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.9.0/js/all.min.js"></script>
    <!-- accessibility active issues -->

    <!-- <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script> -->
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    <script>
        document.addEventListener('keyup', (event) => {
            //var name = event.key; //var code = event.code;
            if (event.code === "Tab") {
                var k = 0;
                if (event.shiftKey) {
                    //shift+tab pressed//Code // console.log(event.target);
                    var activeElement = document.activeElement;
                    if (activeElement.tagName.toLowerCase() == 'button') {
                        if (activeElement.title === 'Download Screen Reader') {
                            $('#myModalClose').attr('id', 'myModal');
                            $('#myModal').modal();
                            return false;
                        }
                    }
                } else {
                    //only tab pressed //Code
                }
            }

        });

        //====================//
        // Add event listener on keydown
        var access = 0;
        if (access === 0) {
            document.addEventListener('keyup', (event) => {
                var name = event.key;
                var code = event.code;
                var i = 0;
                if (code == "Tab" && i == 0) {
                    $('#myModal').modal();
                    i = i + 1;
                }
                // Alert the key name and key code on keydown
            });
            var accessibilitypop = document.querySelector('#accessibilitypop');

            function accessibility() {
                $('#myModal').modal('hide');
                document.getElementById("universalAccessBtn").click();
                $('#myModal').attr('id', 'myModalClose');
                //$('#accessibilityBar').attr('class', 'active');
                $('#myModal').attr('tabindex', '');
                document.getElementById("universalAccessBtn").focus();
                $('#accessibilityBar').attr('role', 'dialog');
                $('#universalAccessBtn').attr('tabindex', '1');
            };

            function accessibilitySkipToMainContent() {
                $('#myModal').attr('tabindex', '');
                $('#myModal').attr('id', 'myModalClose');
                $('#notice-board-bg').attr({
                    'aria-selected': true,
                    'tabindex': 0
                });
                //$('#skip-main-content-start-here').attr({'aria-selected': true, 'tabindex': '-1'});
                document.getElementById("skip-main-content-start-here").focus();
            }

            function accessibilitymodelClose() {
                //$('#notice-board-bg').attr('tabindex', '0');
                $('#skip-main-content-start-here').attr('tabindex', '0');
                $('#myModal').attr('tabindex', '');
                $('#myModal').attr('id', 'myModalClose');
            }

        }

        function start_np() {
            $('#start-np').attr({
                'aria-selected': true,
                'tabindex': 0
            });
            document.getElementById("start-np").focus();
        }
    </script>
    <style>
        #accessibilityBar button#universalAccessBtn {
            border-radius: 0px !important;
        }

        #accessibilityBar {
            top: 360px !important;
        }

        .btn-for-accessibility {
            font-size: 13px;
            background: local;
        }

        /*==================================
         Content share css design
        ===================================*/
        .share-text-style {
            font-family: Hind Siliguri !important;
            color: #662D91;
            font-size: 12px;
        }

        .share-title {
            font-family: Hind Siliguri !important;
            color: #662D91;
            font-size: 17px;
            text-align: left;
            margin-left: 14px;
        }

        .share-youtube-title {
            font-family: Hind Siliguri !important;
            color: #2E2E2E;
            font-size: 9px;
            letter-spacing: 0px;
        }

        .share-content-box {
            display: flex;
            justify-content: end;
            gap: 16px;
            text-align: center;
            align-items: end;
        }

        .at4-jumboshare .at4-count-container {
            min-width: 30px !important;
            padding-right: 0px !important;
        }

        .at4-jumboshare .at4-count {
            padding-left: 0px !important;
            padding-right: 0px !important;
            font-size: 0 !important;
            line-height: 0 !important;
        }

        .at4-jumboshare .at4-share-container {
            padding-left: 10px !important;
        }

        .at4-jumboshare table,
        .at4-jumboshare table tr,
        .at4-jumboshare td,
        .at4-jumboshare table th {
            border: none !important;
        }

        .at-svc-compact {
            display: none !important;
        }

        /*Responsive css*/
        @media only screen and (max-width: 770px) {
            .share-content-box {
                gap: 5px;
            }

            .share-content-box img {
                width: 15px !important;
                height: 13px !important;
            }

            .share-content-box>div {
                margin-right: 0px !important;
            }

            .share-text-style {
                font-size: 9px;
            }

            .share-youtube-title {
                font-size: 8px;
            }

            .at-mobile .at-resp-share-element .at-share-btn {
                padding: 0px !important;
                margin-right: 0px !important;
            }

            .share-title {
                font-size: 10px;
            }

            .at4-jumboshare .at4-share-container {
                padding-left: 3px !important;
            }

            iframe {
                height: 24px !important;
            }
        }
    </style>
    <style>
        /*Addthis print hide css*/
        @media print {

            .hide-for-print,
            #accessibilityBar,
            #onlinePollBlock,
            #onlineCommentBlock {
                display: none !important;
            }
        }
    </style>
    <!-- end accessibility active issues -->
    <!-- custom accessibility end -->
    </head>

<body class="pmo-portal-gov-bd">
    <!-- accessibility Modal -->
    <div class="modal fade" id="myModal" role="dialog" tabindex="-1" style="display: none;margin: 5px;text-align: center;">
        <div class="modal-dialog text-center">
            <!-- Modal content-->
            <div class="modal-content">
                <div class="modal-body">
                    <button class="btn-for-accessibility" data-dismiss="modal" onclick="accessibilitymodelClose()">Skip to main content</button>
                    <button class="btn-for-accessibility" id="accessibilitypop" onclick="accessibility()">Go to accessibility menu</button>
                    <button class="btn-for-accessibility close" type="button" data-dismiss="modal" onclick="accessibilitymodelClose()">&times;</button>
                </div>
            </div>

        </div>
    </div>
    <!--   -->
    <!-- ====== start jump to selections ======   -->
    <a class="skip-link" href="/accessibility.html" target="_blank">Accessibility Help</a>
    <a class="skip-link" href="#jmenu">Jump to Menu</a>
    <a class="skip-link" href="#contents">Jump to Content</a>
    <a class="skip-link" href="#search">Jump to Search</a>
    <a class="skip-link" href="#btnLang">Jump to Language</a>
    <!-- ====== End jump to selections ======   -->


    <div class="container inner-page">
        <div id="start-np" autofocus="autofocus" style="opacity:0;font-size:1px;position: absolute;" aria-selected="true" tabindex="0">Wellcome to National Portal</div>

        
        <script src="//bangladesh.gov.bd/nav/js/obd.main.js?v=1.0.1"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/select2/4.0.5/js/select2.js"></script>
<link rel="stylesheet" media="all" type="text/css" href="//bangladesh.gov.bd/nav/css/obd.main.css">



<div class="sixteen columns"
	style="background-color: #683091; box-shadow: 0 1px 5px #999999;width: 960px;border-bottom: 4px solid #8bc643;">
	<div class="slide-panel-btns" style="float: left;width: 165px;height: 30px">
					<div class="slide-panel-button" style="display: table;margin-top: 5px">
				<!-- <i class="flaticon-menu10"></i> -->
				<a style="color: white;font-size:.9em;" href="https://raselweeb.github.io/bd/" target="_blank">খাঁন অনলাইন পোর্টাল
				</a>
			</div>
			</div>
	<div id="div-lang" style="float:left;width: 795px;height: 32px;">
		<div id="newNavigation"></div>
		<div id="div-lang-sel">
			<div id="search_any" style="float: left">
				<div style="margin-top: 5px;padding: 0;float: left;">
					<input style="width:90px;border-radius: 4px;height: 18px;" id="search_val" name="key" value="" />
					<button class="search-btn" type="button" style="margin: 0;padding: 1px 10px"
						id="search-button">Search</button>
				</div>
				<script>
					// Function to redirect to Google with search query
					function redirectToGoogle() {
						var input = document.getElementById('search_val').value;
						var searchQuery = encodeURIComponent(input);
						var site_url = window.location.origin;
						var site_link = ("https://www.google.com/search?q=" + searchQuery + " " + site_url);

						if (searchQuery != '') {
							window.open(site_link, '_blank');
						} else {
							alert(`যা খুঁজতে চান তা লিখুন`);
						}
					}

					// Event listener for Enter key press
					document.getElementById('search_val').addEventListener('keydown', function (e) {
						if (e.key === 'Enter') {
							redirectToGoogle();
						}
					});

					// Event listener for search button click
					document.getElementById('search-button').addEventListener('click', redirectToGoogle);
				</script>
			</div>
			<div style="float: left;margin-left: 5px">

				<form id="lang_form" action="/site/biography/2e8145ab-3df7-404d-8bb9-ae38daa68eeb" method="post">
																<input type="hidden" name="lang" id="lang" value="en" />
						<button type="submit" style="padding: 2px;margin-top: 5px">English</button>
									</form>
			</div>

		</div>

	</div>
</div>


<div class="sixteen columns">
	<div class="callbacks_container" style="box-shadow: 0 1px 5px #999999;">
		<ul class="rslides" id="front-image-slider">
		<li>
		
		            	
                <img src="https://i.ibb.co/7kG7wKy/IMG-20240119-091210.jpg" alt="" width="960" height="220"/>   
			

            		
		</li>
		<li>
		
		
		<img src="https://i.ibb.co/X5MhT4C/IMG-20240119-091259.jpg" alt="" width="960" height="220"/>   
		
		
		
		</li>
		<li>
		
		
		<img src="https://i.ibb.co/2StgVKY/IMG-20240119-091425.jpg" alt="" width="960" height="220"/>   
		
		
		
		</li>
		<li>
		
		
		<img src="https://i.ibb.co/6mrvxWQ/IMG-20240119-091507.jpg" alt="" width="960" height="220"/>   
		
		
		
		</li>
		<li>
		
		
		<img src="https://i.ibb.co/fDFc26p/IMG-20240119-091945.jpg" alt="" width="960" height="220"/>   
		
		
		
		</li>
		<li>
		
		            	
                <img src="https://kmrasel9748.github.io/tk/bteb.portal.gov.bd/sites/default/files/files/bteb.portal.gov.bd/top_banner/e5cb3521_3429_44f1_83e0_0a9f82271ed4/banner_agriment_sign4.jpg" alt="" width="960" height="220"/>   
			

            		
		</li>
		<li>
		
		            	
                <img src="https://kmrasel9748.github.io/tk/bteb.portal.gov.bd/sites/default/files/files/bteb.portal.gov.bd/top_banner/4d7d49ad_06a1_461b_8835_f820c68c50f3/IMG_20190317_110331%20(1).jpg" alt="" width="960" height="220"/>   
			

            		
		</li>
		<li>
		
		
		<img src="https://i.ibb.co/VSyQdQV/IMG-20240119-092013.jpg" alt="" width="960" height="220"/>   
		
		
		
		</li>
		<li>
		
		
		<img src="https://i.ibb.co/25hb4Yp/IMG-20240119-092106.jpg" alt="" width="960" height="220"/>   
		
		
		
		</li>
		
	</ul><style>.rslides img{height:220px}</style><script></script>	</div>


	<div class="header-site-info" id="header-site-info">

		<div>

			<div id="logo">
									<a title="Home" href="https://raselweeb.github.io/bd/">
						<img alt="Home" src="https://i.ibb.co/KKvrj9f/IMG-20240113-WA0016-removebg-preview.png">
					</a>

			</div>

			<div class="clearfix" id="site-name-wrapper">
				<span id="site-name">
					<a title="Home" href="index.html">
						খাঁন অনলাইন পোর্টাল	</a>
				</span>
				<span id="slogan">
					সকল তথ্য ও সেবা এক ঠিকানায়	</span>
			</div>
			<!-- /site-name-wrapper -->

		</div>
		<!-- /header-site-info-inner -->

	</div>

</div>
<script>
            /* Responsive Design*/
            $(document).ready(function () {
				var wi = $( window ).width();
                if(wi < 980){
                    
					$('#jmenu .show-menu').click(function () {
						//$('.mzr-responsive').show();
						$(".mzr-responsive").slideToggle(400,"linear", function () {
                            
						});
					});
		  
                    $("#jmenu a.submenu").click(function() {
                        
                      $('#jmenu a.submenu').siblings().addClass('sibling-toggle');
                      $(this).parent().find(".mzr-content").removeClass('sibling-toggle').addClass('slide-visible').slideToggle(400,"linear", function() {
                      });
                      return false;
                    });
                } 

            });
            
        </script>
      
  
        <div class="sixteen columns" id="jmenu">
            <div class="sixteen columns">

               <a href="javascript:;" class="show-menu menu-head"> মেনু নির্বাচন করুন</a>
                <div role="navigation" id="dawgdrops">
                    <ul class="meganizr mzr-slide mzr-responsive" >
                        <!-- Build The Menu -->
                        
			    
			    
			  <li class="col0 "><a title="Home" href="https://raselweeb.github.io/bd/" style="background-image: url(https://kmrasel9748.github.io/tk/bteb.gov.bd//themes/responsive_npf/img/home_dark.png);margin-top:5px;"></a></li><li class="col1 mzr-drop"><a href="#" class="submenu">আমার সম্পর্কে</a><div class="mzr-content drop-one-columns"><div class="one-col"><h6> </h6><ul class="mzr-links"><li><a href="site/office_head/9e8a2004-c9b6-4d40-a2dc-a5492f44a805/%E0%A6%AC%E0%A6%BF%E0%A6%B8%E0%A7%8D%E0%A6%A4%E0%A6%BE%E0%A6%B0%E0%A6%BF%E0%A6%A41.html">জন্ম বিত্তান্ত</a></li><li><a href="https://kmrasel9748.github.io/tk/bteb.gov.bd/site/office_head/9e8a2004-c9b6-4d40-a2dc-a5492f44a805/%E0%A6%AC%E0%A6%BF%E0%A6%B8%E0%A7%8D%E0%A6%A4%E0%A6%BE%E0%A6%B0%E0%A6%BF%E0%A6%A47.html">পরিচিতি</a></li><li><a href="site/office_head/9e8a2004-c9b6-4d40-a2dc-a5492f44a805/%E0%A6%AC%E0%A6%BF%E0%A6%B8%E0%A7%8D%E0%A6%A4%E0%A6%BE%E0%A6%B0%E0%A6%BF%E0%A6%A43.html">নিজ সম্পর্কে</a></li><li><a href="site/office_head/9e8a2004-c9b6-4d40-a2dc-a5492f44a805/%E0%A6%AC%E0%A6%BF%E0%A6%B8%E0%A7%8D%E0%A6%A4%E0%A6%BE%E0%A6%B0%E0%A6%BF%E0%A6%A44.html">শিক্ষা জীবন</a></li></ul></div></div></li>
                        
                        
                        
                        
                         <li class="col2 mzr-drop"><a class="submenu" href="#">পাঠ্যক্রম</a><div class="mzr-content drop-one-columns"><div class="one-col"><h6></h6><ul class="mzr-links"><li><a href="	http://www.nu.ac.bd/syllabus-Bachelor-of-Arts-Honours.php">স্নাতক সম্মান</a></li><li><a href="http://commontarget.net/hsc-subjects-new-curriculum/">এইচ এস সি পর্যায়</a></li><li><a href="http://commontarget.net/ssc-subjects-new-curriculum/">এস,এস,সি পর্যায়</a></li><li><a href="https://teachingbd24.com/revised-marks-distribution-for-jsc-jdc-examination-from-2018/">প্রাথমিক,মাধ্যমিক ও অন্যান্য</a></li></ul></div></div></li>
                        
                        
                        
                        
                        
                        <li class="col3 mzr-drop"><a href="#" class="submenu">কবিতা,গল্পগুচ্ছ ও অন্যান্য</a><div class="mzr-content drop-one-columns"><div class="one-col"><h6></h6><ul class="mzr-links"><li><a href="site/office_head/9e8a2004-c9b6-4d40-a2dc-a5492f44a805/%E0%A6%AC%E0%A6%BF%E0%A6%B8%E0%A7%8D%E0%A6%A4%E0%A6%BE%E0%A6%B0%E0%A6%BF%E0%A6%A4777.html">আমার কবিতাগুচ্ছ</a></li><li><a href="https://drive.google.com/file/d/1eDFcoVlkvVhHluAuaF_VbAlBpP-E4bLN/view">গল্প সমগ্র</a></li><li><a href="https://m.somewhereinblog.net/mobile/blog/Eagle/29125413">ফানি স্টোরি</a></li><li><a href="https://www.bdup24.com/category/243/বাংলা-ধাধা">বাংলা ধাঁধাঁ সমগ্র</a></li><li><a href="http://banglahorrorstory.blogspot.com/?m=1">ভূত ও প্রেতের গল্প</a></li><li><a href="https://jamalkhan1952.wordpress.com/2014/06/01/বাংলা-সাহিত্যের-কবি-ও-লেখ/">কবি উক্তি</a></li></ul></div></div></li><li class="col4 mzr-drop"><a class="submenu" href="http://"> রেজাল্ট </a><div class="mzr-content drop-one-columns"><div class="one-col"><h6></h6><ul class="mzr-links"><li><a href="https://www.nu.ac.bd/results/">জাতীয় বিশ্ববিদ্যালয়</a></li><li><a href="http://180.211.162.102:8444/result_arch/index.php">ডিপ্লোমা ইঞ্জিনিয়ারিং</a></li><li><a href="http://www.educationboardresults.gov.bd/">এইচ এস সি পর্যায়</a></li><li><a href="http://www.educationboardresults.gov.bd/">বিএম/ডিকম</a></li><li><a href="http://www.educationboardresults.gov.bd/">এস এস সি পর্যায়</a></li><li><a href="http://180.211.137.51/ResultSingle.aspx">পি এস সি ও অন্যান্য</a></li></ul></div></div></li><li class="col5 "><a class="submenu" href="site/office_head/9e8a2004-c9b6-4d40-a2dc-a5492f44a805/%E0%A6%AC%E0%A6%BF%E0%A6%B8%E0%A7%8D%E0%A6%A4%E0%A6%BE%E0%A6%B0%E0%A6%BF%E0%A6%A45.html">শিক্ষাগত পারফরমেন্স</a></li><li class="col6 "><a class="submenu" href="site/office_head/9e8a2004-c9b6-4d40-a2dc-a5492f44a805/%E0%A6%AC%E0%A6%BF%E0%A6%B8%E0%A7%8D%E0%A6%A4%E0%A6%BE%E0%A6%B0%E0%A6%BF%E0%A6%A46.html">ফটোগ্যালারী</a></li><li class="col7 "><a class="submenu" href="site/office_head/9e8a2004-c9b6-4d40-a2dc-a5492f44a805/%E0%A6%AC%E0%A6%BF%E0%A6%B8%E0%A7%8D%E0%A6%A4%E0%A6%BE%E0%A6%B0%E0%A6%BF%E0%A6%A47.html">যোগাযোগ</a></li>                   
			    
			    
			    
			    
		    </ul>
		    </div>
            </div>
        </div>
<style>
	.right-side-bar .block ul li a {
		font-size: 14px;
	}

	#notice-board ul a {
		font-size: 14px;
	}

	@media screen and (min-width: 1400px) {
		.mainwrapper .box {
			margin-right: 13px
		}
	}
</style>



    <div id="contents" class="sixteen columns">
			<div class="twelve columns" id="left-content">
                        <div class="row mainwrapper">
                <div style=" background-color: #EFEFEF;border: 1px solid #CCCCCC;margin: 20px 0;padding: 10px;" class="row" id="news">
	<h5 style="float:left;margin:-3px 5px 0 0; font-weight:bold;font-size:.9em">খবর:</h5>
	<div id="news-ticker" style="overflow: hidden; position: relative; height: 0px;">
		<ul style="font-size: 0.9em; position: absolute; margin: 0px; padding: 0px; width: 95%;">
<li><a href="https://www.nu.ac.bd/uploads/2018/notice_1617_pub_date_05062022.pdf"></a> ২০২১ সালের অনার্স ৩য় বর্ষ পরীক্ষার পুনঃনিরীক্ষণের ফলাফল প্রকাশ সংক্রান্ত বিজ্ঞপ্তি।</li>
<li><a href="https://www.nu.ac.bd/uploads/notices/exam_schedule-practical_s_pub_date_21012024.pdf"> ২০২২ সালের অনার্স ১ম বর্ষ পরিসংখ্যান ব্যবহারিক পরীক্ষার সময়সূচী ও কেন্দ্র তালিকা।</a></li>
				<li><a href="https://www.nu.ac.bd/uploads/notices/notice_4954_pub_date_21012024.pdf">২০২২ সালের ডিগ্রী পাস ও সার্টিফিকেট কোর্স ১ম বর্ষ পরীক্ষার ফরম পূরণের সময় বৃদ্ধি সংক্রান্ত বিজ্ঞপ্তি।</a></li>   
 	<li><a href="site/news/a990359b-a175-4b21-b01a-c1d9481e088f/%e0%a6%a1%e0%a6%bf%e0%a6%aa%e0%a7%8d%e0%a6%b2%e0%a7%8b%e0%a6%ae%e0%a6%be--%e0%a6%87%e0%a6%a8-%e0%a6%87%e0%a6%9e%e0%a7%8d%e0%a6%9c%e0%a6%bf%e0%a6%83-%e0%a6%aa%e0%a7%8d%e0%a6%b0%e0%a6%a4%e0%a6%bf%e0%a6%a6%e0%a6%bf%e0%a6%a8%e0%a7%87%e0%a6%b0-%e0%a6%aa%e0%a6%b0%e0%a7%80%e0%a6%95%e0%a7%8d%e0%a6%b7%e0%a6%be%e0%a6%b0-%e0%a6%95%e0%a7%87%e0%a6%a8%e0%a7%8d%e0%a6%a6%e0%a7%8d%e0%a6%b0-%e0%a6%b9%e0%a6%a4%e0%a7%87-%e0%a6%b0%e0%a6%bf%e0%a6%aa%e0%a7%8b%e0%a6%b0%e0%a7%8d%e0%a6%9f-%e0%a6%aa%e0%a7%8d%e0%a6%b0%e0%a7%87%e0%a6%b0%e0%a6%a3%e0%a7%87%e0%a6%b0-%e0%a6%b9%e0%a6%9f%e0%a6%b2%e0%a6%be%e0%a6%87%e0%a6%a8%e0%a6%83-%e0%a7%a6%e0%a7%a7%e0%a7%ad%e0%a7%a9%e0%a7%a6%e0%a7%aa%e0%a7%ad%e0%a7%ac%e0%a7%aa%e0%a7%af%e0%a7%a7-%e0%a7%a8-%e0%a6%8f%e0%a6%ac%e0%a6%82-%e0%a6%87-%e0%a6%ae%e0%a7%87%e0%a6%87%e0%a6%b2%e0%a6%83-shahindcbtebgmailcom.html">জাতীয় বিশ্ববিদ্যালয়ের শিক্ষা বিষায়ক প্রতিটি তথ্য পেতে চোখ রাখুন এই সাইটে, হটলাইনঃ ০১৭৮২৭২৯৭৪৮ এবং ই-মেইলঃ kmrasel9748@gmail.com</a> <i>(&#x09E8;&#x09E6;&#x09E7;&#x09ED;-&#x09E7;&#x09E8;-&#x09E6;&#x09EB;)</i></li>   
 	<li><a href="site/news/6424536a-ad14-41df-a814-6d95ace4acfc/%e0%a6%b6%e0%a6%bf%e0%a6%95%e0%a7%8d%e0%a6%b7%e0%a6%be-%e0%a6%a8%e0%a6%bf%e0%a7%9f%e0%a7%87-%e0%a6%97%e0%a7%9c%e0%a6%ac-%e0%a6%a6%e0%a7%87%e0%a6%b6-%e0%a6%b6%e0%a7%87%e0%a6%96-%e0%a6%b9%e0%a6%be%e0%a6%b8%e0%a6%bf%e0%a6%a8%e0%a6%be%e0%a6%b0-%e0%a6%ac%e0%a6%be%e0%a6%82%e0%a6%b2%e0%a6%be%e0%a6%a6%e0%a7%87%e0%a6%b6%e0%a5%a4.html">সার্বিক ব্যবস্থাপনা, সার্বিক পরিচালনায় ও তথ্য সংগ্রহ কার কে এম রাসেল। বিএ অনার্স, জাতীয় বিশ্ববিদ্যালয় ঢাকা</a> <i>(&#x09E8;&#x09E6;&#x09E7;&#x09ED;-&#x09E6;&#x09E7;-&#x09E6;&#x09E7;)</i></li>   
 		</ul>
		<div style="float:right">
			<a class="btn" href="https://www.nu.ac.bd/recent-news-notice.php">সকল</a>
		</div>
	</div>
</div><style></style><script></script><div class="row" id="notice-board">
	<div class="notice-board-bg">
		<h2>নোটিশ বোর্ড</h2>
		
		<div id="notice-board-ticker">
			<ul>
 <li>
<a href="https://www.nu.ac.bd/uploads/notices/notice_2332_pub_date_31012024.pdf">২০২১ সালের অনার্স (সম্মান) ফাইনাল পরীক্ষার নম্বরপত্র বিতরন সংক্রান্ত বিজ্ঞপ্তি</a>
</li>				
<li><a href="https://www.nu.ac.bd/uploads/notices/notice_2734_pub_date_21012024.pdf">জাতীয় বিশ্ববিদ্যালয়ে সহযোগী অধ্যাপক ( ইংরেজি ), প্রভাষক ( ইংরেজি ) স্থায়ী শূন্য পদসমূহে নিয়োগ বিজ্ঞপ্তি।</a></li>
<li><a href="https://www.nu.ac.bd/uploads/notices/exam_schedule-practical_s_pub_date_21012024.pdf"> ২০২২ সালের অনার্স ১ম বর্ষ পরিসংখ্যান ব্যবহারিক পরীক্ষার সময়সূচী ও কেন্দ্র তালিকা।</a></li>
<li><a href="https://www.nu.ac.bd/uploads/2018/notice_1617_pub_date_05062022.pdf">২০২১ সালের অনার্স ৩য় বর্ষ পরীক্ষার পুনঃনিরীক্ষণের ফলাফল প্রকাশ সংক্রান্ত বিজ্ঞপ্তি।</a></li>
				
 <li>
<a href="site/page/4df44549-07e8-42ef-800d-4e7fe0981836/%E0%A6%AB%E0%A6%B0%E0%A6%AE(2).html">বি,এ অনার্স কোর্সের সকল চলতি পরীক্ষাদ্বয়ের সময় সূচি ও প্রোগ্রাম সমূহের বিশ্লেষন</a>
</li>
 
 			</ul>	
			<a class="btn right" href="https://www.nu.ac.bd/recent-news-notice.php">সকল</a>
		</div>
	</div>
</div><style>#notice-board-ticker ul li{
	list-style:none;
}</style><script></script>
		<div class="row">
		<div id="box-1" class="six columns service-box box" >
		<h4>বিশ্ববিদ্যালয় কর্নার</h4>
				<img src="https://cdn1.iconfinder.com/data/icons/education-1-15/151/1-512.png" alt="" width="110" height="90"/>		
				
		<ul class="caption fade-caption" style="margin:0">
			<li><a href="https://kmrasel9748.github.io/newexprience2/1st%20year%20page1.html">স্নাতক সম্মান (১ম বর্ষ)</a></li>
			<li><a href="https://kmrasel9748.github.io/newexprience2/2nd%20year%20page2.html">স্নাতক সম্মান (২য় বর্ষ)</a></li>
			<li><a href="https://kmrasel9748.github.io/.net/3rd%20year%20page3.html">স্নাতক সম্মান (৩য় বর্ষ)</a></li>
			<li><a href="https://kmrasel9748.github.io/newexprience2/4th%20year%20page4.html">স্নাতক সম্মান (৪র্থ বর্ষ)</a></li>
			
		</ul>
	</div>
			<div id="box-1" class="six columns service-box box" >
		<h4>উচ্চ মাধ্যমিক কর্নার </h4>
		<img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQo_2Sz5paCMUtghKCnoUX6u1ZPRzyEeazN1_t1dsQfdfleRiFpKSmUY2A" alt="" width="110" height="90"/>		
		<ul class="caption fade-caption" style="margin:0">
			<li><a href="https://kmrasel9748.github.io/newexprience2/intermidiate%201st%20year.html">একাদশ শ্রেনি (১ম বর্ষ)</a></li>
			<li><a href="https://kmrasel9748.github.io/newexprience2/intermidiate%202nd%20year.html">দ্বাদশ শ্রেনি (২য় বর্ষ)</a></li>
			<li><a href="#">উচ্চ মাধ্যমিক পরীক্ষা (এইচ এস সি)</a></li>
			<li><a href="#">পাঠ্য সিলেবাস</a></li>
			
		</ul>
	</div>
		</div>
			<div class="row">
		<div id="box-2" class="six columns service-box box" >
		<h4>মাধ্যমিক শিক্ষা কর্নার</h4>
		<img src="http://nctb.portal.gov.bd/sites/default/files/files/nctb.portal.gov.bd/front_service_box/19e8b5ae_6ae8_49d4_8d84_81eb15911974/open-book.png" alt="" width="110" height="90"/>		
		<ul class="caption fade-caption" style="margin:0">
			<li><a href="site/page/84fa020e-4ccb-445b-bde4-d8ee2096c670/%e0%a6%a1%e0%a6%bf%e0%a6%aa%e0%a7%8d%e0%a6%b2%e0%a7%8b%e0%a6%ae%e0%a6%be-%e0%a6%aa%e0%a6%b0%e0%a7%8d%e0%a6%af%e0%a6%be%e0%a7%9f.html">দাখিল নবম শ্রেনি</a></li>
			<li><a href="site/page/84fa020e-4ccb-445b-bde4-d8ee2096c670/%e0%a6%8f%e0%a6%87%e0%a6%9a-%e0%a6%8f%e0%a6%b8-%e0%a6%b8%e0%a6%bf-%e0%a6%aa%e0%a6%b0%e0%a7%8d%e0%a6%af%e0%a6%be%e0%a7%9f.html">দাখিল দশম শ্রেনি</a></li>
			<li><a href="site/page/84fa020e-4ccb-445b-bde4-d8ee2096c670/%e0%a6%8f%e0%a6%b8-%e0%a6%8f%e0%a6%b8-%e0%a6%b8%e0%a6%bf-%e0%a6%aa%e0%a6%b0%e0%a7%8d%e0%a6%af%e0%a6%be%e0%a7%9f.html">দাখিল পরীক্ষা </a></li>
			<li><a href="site/page/84fa020e-4ccb-445b-bde4-d8ee2096c670/%e0%a6%b8%e0%a6%b2%e0%a7%8d%e0%a6%aa-%e0%a6%ae%e0%a7%87%e0%a7%9f%e0%a6%be%e0%a6%a6%e0%a7%80-%e0%a6%93-%e0%a6%85%e0%a6%a8%e0%a7%8d%e0%a6%af%e0%a6%be%e0%a6%a8%e0%a7%8d%e0%a6%af.html">ও অন্যান্য ক্ষেত্রসমুহ</a></li>
			
		</ul>
	</div>
			<div id="box-3" class="six columns service-box box" >
		<h4>প্রাথমিক শিক্ষা কর্নার</h4>
		<img src="http://nctb.portal.gov.bd/sites/default/files/files/nctb.portal.gov.bd/front_service_box/9fab4051_90c4_41b4_9e47_e8b21f61bf24/girl-with-ponytails%20(4).png" alt="" width="110" height="90"/>		
		<ul class="caption fade-caption" style="margin:0">
			<li><a href="site/page/c14cacbd-560b-4e82-9b62-f52a90338367/%e0%a6%a1%e0%a6%bf%e0%a6%aa%e0%a7%8d%e0%a6%b2%e0%a7%8b%e0%a6%ae%e0%a6%be-%e0%a6%aa%e0%a6%b0%e0%a7%8d%e0%a6%af%e0%a6%be%e0%a7%9f.html">লানিং স্কেল (২০০৪-০৮)</a></li>
			<li><a href="site/page/c14cacbd-560b-4e82-9b62-f52a90338367/%e0%a6%8f%e0%a6%87%e0%a6%9a-%e0%a6%8f%e0%a6%b8-%e0%a6%b8%e0%a6%bf-%e0%a6%aa%e0%a6%b0%e0%a7%8d%e0%a6%af%e0%a6%be%e0%a7%9f.html">মাদ্রাসা শিক্ষা</a></li>
			<li><a href="site/page/c14cacbd-560b-4e82-9b62-f52a90338367/%e0%a6%8f%e0%a6%b8%2c%e0%a6%8f%e0%a6%b8%2c%e0%a6%b8%e0%a6%bf-%e0%a6%aa%e0%a6%b0%e0%a7%8d%e0%a6%af%e0%a6%be%e0%a7%9f.html">বৃত্তি পরীক্ষা</a></li>
			<li><a href="http://www.dpe.gov.bd/">প্রাথমিক শিক্ষা সমাপনী</a></li>
			
		</ul>
	</div>
		</div>
			<div class="row">
		<div id="box-4" class="six columns service-box box" >
		<h4>রেজাল্টশীট কর্নার</h4>
		<img src="site/media/uploads/homepage content/8.png" alt="" width="110" height="90"/>		
		<ul class="caption fade-caption" style="margin:0">
			<li><a href="https://kmrasel9748.github.io/newexprience2/Jdc.html">জুনিয়র সমাপনি (Jsc)</a></li>
			<li><a href="https://kmrasel9748.github.io/newexprience2/Ssc.html">মাধ্যমিক সমাপনি (Ssc) </a></li>
			<li><a href="https://kmrasel9748.github.io/newexprience2/Hsc.html">উচ্চ মাধ্যমিক শিক্ষা (Hsc)</a></li>
			<li><a href="#">উচ্চ শিক্ষা (BA Hon's) </a></li>
			
			<li><a href="site/page/98ee717c-8288-446d-b091-b7cfc18bdc22/%e0%a6%b8%e0%a6%b2%e0%a7%8d%e0%a6%aa-%e0%a6%ae%e0%a7%87%e0%a7%9f%e0%a6%be%e0%a6%a6%e0%a7%80-%e0%a6%93-%e0%a6%85%e0%a6%a8%e0%a7%8d%e0%a6%af%e0%a6%be%e0%a6%a8%e0%a7%8d%e0%a6%af.html">কারিগরি শিক্ষা (Bm)</a></li>
			
		</ul>
	</div>
			<div id="box-5" class="six columns service-box box" >
		<h4>কারিগরি শিক্ষা কর্নার</h4>
		<img src="site/media/uploads/homepage content/6.png" alt="" width="110" height="90"/>		
		<ul class="caption fade-caption" style="margin:0">
			<li><a href="https://kmrasel9748.github.io/newexprience2/Computer">কম্পিউটার</a></li>
			<li><a href="https://www.sec.ac.bd/">ইঞ্জিনিয়ারিং</a></li>
			<li><a href="https://kmrasel9748.github.io/.net/www.eduicon.com/Institute/More/?page=institute.php&Institute_Nature_ID=2&Institute_Category_ID=2&Degree_Level_ID=1">ডিপ্লমা</a></li>
			<li><a href="buft.edu.bd/index.php">সিভিল এন্ড টেক্সটাইল</a></li>
			
		</ul>
	</div>
		</div>
			<div class="row">
		<div id="box-6" class="six columns service-box box" >
		<h4>আমার প্রোগ্রাম সমূহ</h4>
		<img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQP3DMP9qz3FmvE3KT60UGn4g1whqxVa8pXPgImQgIw9_wH5g5n17DABw" alt="" width="110" height="90"/>		
		<ul class="caption fade-caption" style="margin:0">
			<li><a href="site/office_head/9e8a2004-c9b6-4d40-a2dc-a5492f44a805/%E0%A6%AC%E0%A6%BF%E0%A6%B8%E0%A7%8D%E0%A6%A4%E0%A6%BE%E0%A6%B0%E0%A6%BF%E0%A6%A46.html">ফটোগ্রাফি</a></li>
			<li><a href="site/biography/e58c7488-d4ce-4986-8cbd-6d0b5366d23c/database.html">পার্সোনাল ডকুমেন্ট</a></li>
			<li><a href="https://kmrasel9748.github.io/tk/bteb.gov.bd/site/office_head/9e8a2004-c9b6-4d40-a2dc-a5492f44a805/%E0%A6%AC%E0%A6%BF%E0%A6%B8%E0%A7%8D%E0%A6%A4%E0%A6%BE%E0%A6%B0%E0%A6%BF%E0%A6%A4777.html">কবিতাসমূহ</a></li>
			<li><a href="https://dik-grantha.com">লাইব্রেরী</a></li>
			
		</ul>
	</div>
			<div id="box-6" class="six columns service-box box" >
		<h4>ব্যক্তিগত সাইট কর্নার</h4>
		<img src="site/media/uploads/homepage content/2.png" alt="" width="110" height="90"/>		
		<ul class="caption fade-caption" style="margin:0">
			<li><a href="../external.html?link=https://drive.google.com/folderview?id=0BynIJ2cATXt3NmxhWC1JTDd3RHc&amp;usp=sharing">পার্সোনাল বায়োডাটা</a></li>
			<li><a href="site/page/4df44549-07e8-42ef-800d-4e7fe0981836/%e0%a6%ab%e0%a6%b0%e0%a6%ae.html">প্রোফাইল</a></li>
			<li><a href="https://raselweeb.github.io/bd/site/biography/e58c7488-d4ce-4986-8cbd-6d0b5366d23c/aaaaaaaaaaa.html">ফ্যামিলী ফটো</a></li>
			<li><a href="site/office_head/9e8a2004-c9b6-4d40-a2dc-a5492f44a805/%e0%a6%ac%e0%a6%bf%e0%a6%b8%e0%a7%8d%e0%a6%a4%e0%a6%be%e0%a6%b0%e0%a6%bf%e0%a6%a47.html">যোগাযোগ</a></li>
			
		</ul>
	</div>
		</div>
			<div class="row">
		<div id="box-7" class="six columns service-box box" >
		<h4>প্রাতিষ্ঠানিক ওয়েবসাইট</h4>
		<img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQfXJL5OmlHqnJoJWkIk6DpupxvsjzWM5VxVSFpRloqdfgllbyp8N7X2mLh" alt="" width="110" height="90"/>		
		<ul class="caption fade-caption" style="margin:0">
			<li><a href="https://smcollegemorrelgonj.jessoreboard.gov.bd/">সরকারি এস এম কলেজ</a></li>
			<li><a href="http://www.nu.ac.bd/">জাতীয় বিশ্ববিদ্যালয়</a></li>
			<li><a href="http://www.bteb.gov.bd/">কারিগরি শিক্ষাবোর্ড</a></li>
			<li><a href="https://jessoreboard.gov.bd/">মাধ্যমিক ও উচ্চমাধ্যমিক শিক্ষাবোর্ড,যশোর</a></li>
			
		</ul>
	</div>
			<div id="box-8" class="six columns service-box box" >
		<h4>সোসাল মিডিয়া কর্নার</h4>
				<img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTEOLJ1zgqYwgbN86KVv5nLSLr2F0DSgOHgi_yBk-lQpl6xguuWn4Az9pWC" alt="" width="110" height="90"/>		
				
		<ul class="caption fade-caption" style="margin:0">
			<li><a href="https://facebook.com">Facebook</a></li>
			<li><a href="https://jessoreboard.gov.bd/">Youtube</a></li>
			<li><a href="https://google.com">Google sarch</a></li>
			<li><a href="https://bing.con">Bing sarch</a></li>
			
		</ul>
	</div>
		</div>
			<div class="row">
		<div id="box-9" class="six columns service-box box" >
		<h4>শিক্ষাগত সাইট কর্নার</h4>
				<img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRVzcWKKMkvHsvQlrpLbADi0KXMtYfh-BAqDVUoViViA9JGzEeypfxuCOWc" alt="" width="110" height="90"/>		
				
		<ul class="caption fade-caption" style="margin:0">
			<li><a href="https://bn.khanacademy.org/">খাঁন একাডেমি</a></li>
			<li><a href="https://bn.m.wikipedia.org/wiki/বাংলা_উইকিপিডিয়া">উইকিপিডিয়া বাংলা</a></li>
			<li><a href="http://nctb.gov.bd/">জাতীয় শিক্ষাক্রম ও পাঠ্যপুস্তক বোর্ড</a></li>
			<li><a href="http://shikkhok.com/কোর্স-তালিকা/">শিক্ষক</a></li>
			
		</ul>
	</div>
			<div id="box-10" class="six columns service-box box" >
		<h4>বাংলাদেশের কিছু প্রান্ত</h4>
				<img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTgtudlWztqfMTcj7P2zBX8Nh7UQnAIXj3apVYEtN6c5fVK3pngnfWGTig" alt="" width="110" height="90"/>		
				
		<ul class="caption fade-caption" style="margin:0">
			<li><a href="https://www.shutterstock.com/search/bangladesh+river">The Rivers</a></li>
			<li><a href="site/page/ea3b736c-0f87-4602-b2f2-1bc1232d70de/%e0%a6%ac%e0%a6%be%e0%a6%b0%e0%a7%8d%e0%a6%b7%e0%a6%bf%e0%a6%95-%e0%a6%95%e0%a6%b0%e0%a7%8d%e0%a6%ae%e0%a6%aa%e0%a6%b0%e0%a6%bf%e0%a6%95%e0%a6%b2%e0%a7%8d%e0%a6%aa%e0%a6%a8%e0%a6%be-%e0%a6%aa%e0%a7%8d%e0%a6%b0%e0%a6%a3%e0%a7%9f%e0%a6%a8.html">The Forest</a></li>
			<li><a href="#">The animals</a></li>
			<li><a href="operette:/certissue?u=https%3A%2F%2Fwww.bangladeshmuseum.gov.bd%2F&i=64a443c9-bc03-4403-9302-ded508011fa7">The Mugiums</a></li>
			
		</ul>
	</div>
	
	
	
	
		</div>
		<div class="row">
		<div id="box-9" class="six columns service-box box" >
		<h4>মিডিয়া ডাউনলোড সাইট</h4>
		<img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQAXYcOcOIAMAGwmC8qTAMF1hLpl8u4ckZ3vGwealhS7-UmKwSEw9NexhY" alt="" width="110" height="90"/>		
		
		<ul class="caption fade-caption" style="margin:0">
		<li><a href="site/page/dfbfe834-cc44-4b1b-8740-dce4a2608d24/%e0%a6%9c%e0%a6%be%e0%a6%a4%e0%a7%80%e0%a7%9f-%e0%a6%b6%e0%a7%81%e0%a6%a6%e0%a7%8d%e0%a6%a7%e0%a6%be%e0%a6%9a%e0%a6%be%e0%a6%b0-%e0%a6%95%e0%a7%8c%e0%a6%b6%e0%a6%b2.html">Fusion BD</a></li>
		<li><a href="#">Youtube</a></li>
		<li><a href="site/page/9ccde921-fe03-4efa-a46d-ea5e1d7608a5/%e0%a6%95%e0%a6%b0%e0%a7%8d%e0%a6%ae-%e0%a6%aa%e0%a6%b0%e0%a6%bf%e0%a6%95%e0%a6%b2%e0%a7%8d%e0%a6%aa%e0%a6%a8%e0%a6%be-%e0%a6%93-%e0%a6%95%e0%a6%ae%e0%a6%bf%e0%a6%9f%e0%a6%bf.html">Bd music24</a></li>
		<li><a href="site/page/cf37ae83-a6d2-46cb-8659-769777ccbfb0/%e0%a6%aa%e0%a7%8d%e0%a6%b0%e0%a6%ae%e0%a6%bf%e0%a6%a4-%e0%a6%aa%e0%a6%b0%e0%a6%bf%e0%a6%9a%e0%a6%be%e0%a6%b2%e0%a6%a8%e0%a6%be-%e0%a6%aa%e0%a6%a6%e0%a7%8d%e0%a6%a7%e0%a6%a4%e0%a6%bf.html">Waptrick</a></li>
		
		</ul>
		</div>
		<div id="box-10" class="six columns service-box box" >
		<h4>অনলাইন পত্র-পত্রিকা</h4>
		<img src="site/media/uploads/homepage content/3.png" alt="" width="110" height="90"/>		
		
		<ul class="caption fade-caption" style="margin:0">
		<li><a href="https://www.prothomalo.com/">দৈনিক প্রথম আলো</a></li>
		<li><a href="http://www.dailynayadiganta.com/">দৈনিক নয়া দিগন্ত</a></li>
		<li><a href="http://www.dailysangram.com/">দৈনিক সংগ্রাম</a></li>
		<li><a href="https://www.jugantor.com/">দৈনিক যুগান্তর</a></li>
		
		</ul>
		</div>
		
		
		
		
		</div>
		<div class="row">
		<div id="box-9" class="six columns service-box box" >
		<h4>শুদ্ধাচার</h4>
		<img src="http://bteb.portal.gov.bd/sites/default/files/files/bteb.portal.gov.bd/front_service_box/bd13681f_9e80_47f6_95c1_4525a0042c90/others2.jpg" alt="" width="110" height="90"/>		
		
		<ul class="caption fade-caption" style="margin:0">
		<li><a href="site/page/dfbfe834-cc44-4b1b-8740-dce4a2608d24/%e0%a6%9c%e0%a6%be%e0%a6%a4%e0%a7%80%e0%a7%9f-%e0%a6%b6%e0%a7%81%e0%a6%a6%e0%a7%8d%e0%a6%a7%e0%a6%be%e0%a6%9a%e0%a6%be%e0%a6%b0-%e0%a6%95%e0%a7%8c%e0%a6%b6%e0%a6%b2.html">জাতীয় শুদ্ধাচার কৌশল</a></li>
		<li><a href="#"></a></li>
		<li><a href="site/page/9ccde921-fe03-4efa-a46d-ea5e1d7608a5/%e0%a6%95%e0%a6%b0%e0%a7%8d%e0%a6%ae-%e0%a6%aa%e0%a6%b0%e0%a6%bf%e0%a6%95%e0%a6%b2%e0%a7%8d%e0%a6%aa%e0%a6%a8%e0%a6%be-%e0%a6%93-%e0%a6%95%e0%a6%ae%e0%a6%bf%e0%a6%9f%e0%a6%bf.html">কর্ম-পরিকল্পনা ও কমিটি</a></li>
		<li><a href="site/page/cf37ae83-a6d2-46cb-8659-769777ccbfb0/%e0%a6%aa%e0%a7%8d%e0%a6%b0%e0%a6%ae%e0%a6%bf%e0%a6%a4-%e0%a6%aa%e0%a6%b0%e0%a6%bf%e0%a6%9a%e0%a6%be%e0%a6%b2%e0%a6%a8%e0%a6%be-%e0%a6%aa%e0%a6%a6%e0%a7%8d%e0%a6%a7%e0%a6%a4%e0%a6%bf.html">প্রমিত পরিচালনা পদ্ধতি</a></li>
		
		</ul>
		</div>
		<div id="box-10" class="six columns service-box box" >
		<h4>ম্যাজিক্যাল ওয়েবসাইট</h4>
		<img src="site/media/uploads/homepage content/4.png" alt="" width="110" height="90"/>		
		
		<ul class="caption fade-caption" style="margin:0">
		<li><a href="http://www.thefacesoffacebook.com/">The world faces</a></li>
		<li><a href="https://www.printfriendly.com/">Page Printers</a></li>
		<li><a href="https://zoomquilt.org">Zombie Effect</a></li>
		<li><a href="https://yyyyyyy.info">The Funny Effect</a></li>
		
		</ul>
		</div>
		
		
		
		
		</div>
		
		
		
		
		
		
		
		
		
	<style>
	.six columns service-box box{
	box-shadow:1px 5px 8px 0px;
	}
	
	
	
	
	
	</style><script></script><div class="column block">
	
<h5 class="bk-org title">
  ভিডিও গ্যালেরী 
  </h5>
  
<p>
	  <iframe frameborder="0" height="315" src="https://www.youtube.com/embed/H-Fgh022lac"width="720"></iframe></p>
<p>
    </p>
    
    




<style></style><script></script>   

	
<h5 class="bk-org title">
  ইমেজ গ্যালেরী 
  </h5>
 <link rel="stylesheet" type="text/css"
          href="https://mopa.gov.bd/themes/responsive_npf/js/ad_slider/jquery.ad-gallery.css">

    <script type="text/javascript"
            src="https://mopa.gov.bd/themes/responsive_npf/js/ad_slider/jquery.ad-gallery.js"></script>

    <script type="text/javascript">
        $(function () {
            var galleries = $('.ad-gallery').adGallery({
                width:'100%'
            });
        });
    </script>
    <style>
        .ad-description-title {
            background-color: #f5f5f5;
            padding: 3px;
            opacity: .8
        }
    </style>

<div id="gallery" class="ad-gallery">
        <div class="ad-image-wrapper">
            <div class="ad-image" style="width:100%">
            </div>

            <img class="ad-loader"
                 src="loader.gif"
                 style="display: none;">

            <div class="ad-next" style="height: 295px;">
                <div class="ad-next-image" style="opacity: 0.7; display: none;"></div>
            </div>
            <div class="ad-prev" style="height: 295px;">
                <div class="ad-prev-image" style="opacity: 0.7; display: none;"></div>
            </div>
        </div>
        <div class="ad-controls"></div>
        <div class="ad-nav">
            <div class="ad-back" style="opacity: 0.6;"></div>
            <div class="ad-thumbs">
                <ul class="ad-thumb-list" style="width: 1665px;">
                <li>

<a href="site/media/uploads/homepage content/1734325799102.jpg" width="500px" height="300px"
                    class="">
                    <img src="site/media/uploads/homepage content/1734325799102.jpg"
                    title="শেখ রাসেল দিবস ২০২৩, শেখ রাসেল দীপ্তিময় নির্ভীক নির্মল দুর্জয়"
                    alt="" class="" style="opacity: 0.7;" width="100"
                    height="60">
                    </a>
                    </li>

                    <a href="site/media/uploads/Rasel Khan-fd resturant.jpg"
                    class="">
                    <img src="site/media/uploads/Rasel Khan-fd resturant.jpg"
                    title="শেখ রাসেল দিবস ২০২৩, শেখ রাসেল দীপ্তিময় নির্ভীক নির্মল দুর্জয়"
                    alt="" class="" style="opacity: 0.7;" width="100"
                    height="60">
                    </a>
                    </li>
               

 	

                    <a href="site/media/uploads/Rasel Khan-nature.jpg"
                    class="">
                    <img src="site/media/uploads/Rasel Khan-nature.jpg"
                    title="শেখ রাসেল দিবস ২০২৩, শেখ রাসেল দীপ্তিময় নির্ভীক নির্মল দুর্জয়"
                    alt="" class="" style="opacity: 0.7;" width="100"
                    height="60">
                    </a>
                    </li>
<a href="site/media/uploads/Rasel-exam-end.jpg"
                    class="">
                    <img src="site/media/uploads/Rasel-exam-end.jpg"
                    title="শেখ রাসেল দিবস ২০২৩, শেখ রাসেল দীপ্তিময় নির্ভীক নির্মল দুর্জয়"
                    alt="" class="" style="opacity: 0.7;" width="100"
                    height="60">
                    </a>
                    </li>
<a href="site/media/uploads/Rasel-exam-end2.jpg"
                    class="">
                    <img src="site/media/uploads/Rasel-exam-end2.jpg"
                    title="শেখ রাসেল দিবস ২০২৩, শেখ রাসেল দীপ্তিময় নির্ভীক নির্মল দুর্জয়"
                    alt="" class="" style="opacity: 0.7;" width="100"
                    height="60">
                    </a>
                    </li>
<a href="site/media/uploads/Rasel-exam-end3.jpg"
                    class="">
                    <img src="site/media/uploads/Rasel-exam-end3.jpg"
                    title="শেখ রাসেল দিবস ২০২৩, শেখ রাসেল দীপ্তিময় নির্ভীক নির্মল দুর্জয়"
                    alt="" class="" style="opacity: 0.7;" width="100"
                    height="60">
                    </a>
                    </li>
<a href="site/media/uploads/Rasel-exam-end4.jpg"
                    class="">
                    <img src="site/media/uploads/Rasel-exam-end4.jpg"
                    title="শেখ রাসেল দিবস ২০২৩, শেখ রাসেল দীপ্তিময় নির্ভীক নির্মল দুর্জয়"
                    alt="" class="" style="opacity: 0.7;" width="100"
                    height="60">
                    </a>
                    </li>

<a href="site/media/uploads/Rasel-exam-end5.jpg"
                    class="">
                    <img src="site/media/uploads/Rasel-exam-end5.jpg"
                    title="শেখ রাসেল দিবস ২০২৩, শেখ রাসেল দীপ্তিময় নির্ভীক নির্মল দুর্জয়"
                    alt="" class="" style="opacity: 0.7;" width="100"
                    height="60">
                    </a>
                    </li>



</ul>
            </div>
</div>
            <div class="ad-forward" style="opacity: 0.6;"></div>
        </div>
    

</div>
    <br/>
<style>.ad-gallery .ad-info{width:200px}
.ad-thumb-list{list-style:none!important}
.ad-gallery{width:100%!important}
.ad-image{width:100%!important;top:0px!important;height:432px!important}
.ad-image img{width:100%!important;height:432px!important}
.ad-image .ad-image-description{width:100%!important}
ad-gallery .ad-image-wrapper {
  height: 432px;
}
.ad-thumbs{height:70px}</style>





<style>#right-content .block { display:block !important}</style><script></script>            </div>
			</div>
			<div class="four columns right-side-bar" id="right-content">
            <script>
	$(document).ready(function(){
		el = $('h5:contains("সেবা সহজিকরণ")');
		text = el.html()
		el.html('').html('<a style="color:#fff" href="/site/view/sps_data">'+text+'<a>');
	});
</script><style></style><script></script>


	








                    <div class="column block">
	<h5 class="bk-org title">
  		<p>জুনিয়র এক্সিকিউটিভ (টিসি)</p>  	</h5>
  
  <p style="text-align:justify"><img alt="" src="https://kmrasel9748.github.io/tk/bteb.portal.gov.bd/sites/default/files/files/bteb.portal.gov.bd/office_head/da821081_9b67_4766_8895_0bfebd65eb78/Minister.jpg" style="float:left; height:167px; margin:10px; width:140px" /> আমি একজন ইতিবাচক, দৃঢ়চেতা এবং আত্মবিশ্বাসী মানুষ। জীবনের প্রতিটি মুহূর্তে শিখতে চাই, নতুন চ্যালেঞ্জ গ্রহণ করি এবং অন্যদের সাহায্য করে, ভালোবাসা, হাসি, সহানুভূতি ও সুখ ছড়িয়ে দিতে বিশ্বাস করি। <strong><a href="site/biography/e58c7488-d4ce-4986-8cbd-6d0b5366d23c/biography.html"><span style="color:#008080">বিস্তারিত...</span></a><span style="color:#008080">.</span></strong></p>

<p>&nbsp;</p>
<p>
    </p>
</div>














				
<div class="column block">
	<h5 class="bk-org title">
	<p>ওয়েব ডিজাইনার</p>
	
	
	</h5>
	
	<img src="Rassel khan.jpg"width="180px" height="190"/></p>
	
			<p class="imgcenterofficehead">	<p><span style="font-size:16px"><strong><span style="color:rgb(68, 68, 68)">জুনায়েদ খাঁন রাসেল, ওয়েব
	<p>
		<a href="site/achievement/web-designer.html">বিস্তারিত</a>	</p>
</div>
<div class="column block">
	<h5 class="bk-org title">
	<p>স্নাতক-সম্মান ডিগ্রীধারী</p>
	
	
	</h5>
	
	<img src="https://i.ibb.co/7zn1wmz/1705050222486.png"width="180px" height="190px"/></p>
	
			<p class="imgcenterofficehead">	
				<p style="text-align:left"><span style="font-size:16px"><strong>জুনায়েদ খাঁন রাসেল, বিএ (অনার্স)</strong></span></p>
	<p>
		<a href="site/achievement/graduation-degree.html">বিস্তারিত</a>	</p>
</div>
<div class="column block">
	<h5 class="bk-org title">
	<p>কম্পিউটার&nbsp;অফিস</p>
	
	
	</h5>
	
	<img src="site/images-gallary/family/RASEL_KHAN.png"width="190px" height="195px"/></p>
	
		<p class="imgcenterofficehead"><p style="font-size:16px;">জুনায়েদ খাঁন রাসেল, এমএস (অফিস)</p>

	<p>
		<a href="site/achievement/computer-office.html">বিস্তারিত</a>	</p>
</div>
<style>.column.block a{
text-decoration:underline;
}

#right-content img {
    margin-right: 20px;
}

.imgcenterofficehead {
	padding-left: 50px;
}</style><script></script><div class="column block">
		
		
		

		
		
	<h5 class="bk-org title">অভ্যন্তরীণ ই-সেবা
	</h5>
				<ul>
				
				
				<li><a href="mailto:kmrasel9748@gmail.com">ওয়েব মেইল</a></li>
					</ul>
			<a href="site/view/internal_eservices.html" style="display:block;text-align:right;text-decoration:underline;">সকল </a>
		
	<!-- <a href="/site/view/internal_eservices" class="btn" style="display:block;text-align:center;">সকল ই-সেবা</a> -->
	<!--<a href="/site/view/internal_eservices" style="display:block;text-align:right;text-decoration:underline;">সকল </a>> -->
	
</div>
<style></style><script></script><div class="column block central-eservices">
	<h5 class="bk-org title eservice-title">কেন্দ্রীয় ই-সেবা
	</h5>
				<ul>
				
				
				<li class="item_1"><a href="http://service.gov.bd/">অনলাইনে সেবার আবেদন</a></li>
							
				
				<li class="item_2"><a href="http://www.nothi.gov.bd/users/login">নথি</a></li>
							
				
				<li class="item_3"><a href="http://bangladesh.gov.bd/site/page/5c238920-a65f-4168-9c2b-70c39dc7cb1c">প্রয়োজনীয় এপস </a></li>
							
				
				<li class="item_4"><a href="http://bris.lgd.gov.bd/pub/?pg=application_form">জন্ম ও মৃত্যু নিবন্ধন</a></li>
							
				
				<li class="item_5"><a href="http://উত্তরাধিকার.বাংলা/">উত্তরাধিকার ক্যালকুলেটর</a></li>
							
				
				<li class="item_6"><a href="http://pcc.police.gov.bd/en/f?p=500:1:::NO:::">অনলাইন পুলিশ ক্লিয়ারেন্স</a></li>
							
				
				<li class="item_7"><a href="http://www.dip.gov.bd/site/page/f2d015a9-1132-4426-8eef-147f1c4bac8a">অনলাইনে পাসপোর্টের আবেদন</a></li>
							
				
				<li class="item_8"><a href="https://services.nidw.gov.bd/">জাতীয় পরিচয়পত্রের তথ্য হালনাগাদকরণ</a></li>
							
				
				<li class="item_9"><a href="http://www.cga.gov.bd/index.php?option=com_wrapper">অনলাইন চালান যাচাইকরণ</a></li>
							
				
				<li class="item_10"><a href="https://www.etaxnbr.gov.bd/tpos/home">অনলাইন আয়কর পরিশোধ</a></li>
							
				
				<li class="item_11"><a href="http://www.bmet.gov.bd/BMET/onlinaVisaCheckAction"> ভিসা যাচাই </a></li>
							
				
				<li class="item_12"><a href="http://eservice.bkkb.gov.bd/">বিকেকেবি শিক্ষাবৃত্তির আবেদন</a></li>
							
				
				<li class="item_13"><a href="http://accessibledictionary.gov.bd/">অভিগম্য অভিধান</a></li>
								</ul>
			</div>
<style>.eservice-title {
    background-color: #609513 !important;
    color: #fff;
    font-size: 12px;
    padding: 5px;
}
.block ul li {
  background: rgba(0, 0, 0, 0) url("themes/responsive_npf/images/bg_block_list.png") no-repeat scroll center bottom;
  font-size: 120%;
  height: auto;
  list-style-type: none;
  margin-bottom: 5px;
  padding-bottom: 8px;
  padding-left: 32px;
  padding-top: 0;
}

body.bpsc-portal-gov-bd .wsis_prize{display:none}</style><script></script>
<div class="column block">
  <h5 class="bk-org title">গুরুত্বপূর্ণ লিংক
  </h5>
        <ul>
        
        <li><a href="http://www.bangladesh.gov.bd/">গণপ্রজাতন্ত্রী বাংলাদেশ সরকার</a></li>
        
        <li><a href="http://www.moedu.gov.bd/">শিক্ষা মন্ত্রণালয়</a></li>
        
        <li><a href="http://www.educationboard.gov.bd/">আন্ত: শিক্ষা বোর্ড</a></li>
        
        <li><a href="http://www.dshe.gov.bd/">মাউশি</a></li>
        
        <li><a href="www.techedu.gov.html">কারিগরি শিক্ষা অধিদপ্তর</a></li>
        
        <li><a href="http://www.banbeis.gov.bd/">বেনবেইস</a></li>
		
        
        <li><a href="http://163.47.156.102/eiin/">অনলাইন EIIN আবেদন</a></li>
          </ul>
  <!-- <a href="/site/view/important_links" class="btn" style="display:block;text-align:center;">সকল লিংকসমূহ</a> -->
   <a href="site/view/important_links.html" style="display:block;text-align:right;text-decoration:underline;">সকল</a>
  </div>
<style></style><script></script><div class="column block">
	<h5 class="bk-org title">ইনোভেশন কর্নার
	</h5>
<img src="https://media2.giphy.com/media/UZ6JTcEQ1I8I8/200w.webp?cid=790b76115d115c2c346e483859581320&rid=200w.webp"width="230"height="150">
	
	</div>
<style></style><script></script><div class="column block">
	<h5 class="bk-org title">
	জাতীয় সংগীত	
	</h5>
<audio controls="" style="width:100%">
 <source src="https://kmrasel9748.github.io/tk/bteb.gov.bd/sites/default/files/files/cabinet.portal.gov.bd/page/e5f25d4e_f0a7_4b2a_a07c_3ec69a793516/bd_national_anthem.mp3" type="audio/mp3">
</audio>
</div><style></style><script></script><div class="column block">


			
			<h5 class="bk-org title">
  দর্শক সংখ্যা 
  </h5>
  
   <!-- hitwebcounter Code START -->
    <a href="https://www.hitwebcounter.com" target="_blank">
    <img src="https://hitwebcounter.com/counter/counter.php?page=10827546&style=0025&nbdigits=9&type=page&initCount=142678" title="Counter Widget" Alt="Visit counter For Websites"   border="0" /></a>                                    
    
   

			
			
			
			
			
			
	
</div>
<div class="clearfix"></div><style>.share-buttons img {
		width: 30px;
		padding: 2px;
		border: 0;
		box-shadow: 0;
		display: inline;
}</style><script></script>            <!-- <div style="" class="column block">

                        <h5 style="background-color: #eee;">
                                                                                                            দর্শক সংখ্যাঃ
                                                <span style="padding:5px; background-color: #609513; color: #fff; font-weight:bold;">
                                                    <span>
                        </h5>
                    </div> -->
                    </div>
                    
                    
                    
                    
                    
                    
                 
                    
		</div>
	</div>
	<!-- container -->
	
	
<div class="footer-artwork" id="footer-artwork">&nbsp;</div>
	<div class="footer-wrapper full-width" id="footer-wrapper">
		<div id="footer-menu">

        <ul><li><a href="site/office/e39bf135-1850-4434-a1a5-20041e636dad/%e0%a6%ae%e0%a7%8d%e0%a6%af%e0%a6%be%e0%a6%aa.html">ফেসবুক</a></li><li><a href="site/view/sitemap/%e0%a6%b8%e0%a6%be%e0%a6%87%e0%a6%9f%e0%a6%ae%e0%a7%8d%e0%a6%af%e0%a6%be%e0%a6%aa.html">ইনস্ট্রাগ্রাম</a></li><li><a href="../external.html?link=https://bteb.portal.gov.bd/site/page/1e71c906-bbfc-43e2-bda1-f4f436b03110">লিংকিন</a></li><li><a href="../external.html?link=http://bteb.portal.gov.bd/site/page/859b6dd7-7566-48b5-8e2f-19daa43cb103">পুর্বের ওয়েবসাইট</a></li></ul>                    <div style="float: left; font-size: .9em;">
				সাইটটি শেষ হাল-নাগাদ করা হয়েছে: <span style="font-style: italic;">&#x09E8;&#x09E6;&#x09E7;&#x09EF;-&#x09E6;&#x09E9;-&#x09E7;&#x09EE; &#x09E8;&#x09E9;:&#x09EA;&#x09EC;:&#x09EB;&#x09EF;</span>
				<!--<span><a href="http://support.portal.gov.bd/" style="color: green" target="_blank"> | <u>হেল্পডেস্ক</u></a></span>-->
			</div>
            </div>

		<div class="footer-credit" id="footer">
        <!--  -->
        
            <p>
                পরিকল্পনা ও বাস্তবায়নে:&nbsp;
                <a href="#">এইচটিএমএল</a>,&nbsp;
                <a href="#">সিএসএস</a>,&nbsp;
                <a href="#/">জাভাস্ক্রিপ্ট</a>,&nbsp;
                <a href="#/">পিএইচটি</a>&nbsp;ও&nbsp;
                <a href="#">বুস্ট্রাপ</a>।
            </p>

            <!-- <p>
                কারিগরি সহায়তায়:<a href="https://a2i.gov.bd"><img
                    style=""
                    src="/themes/responsive_npf/img/a2i.png"
                    alt=""></a>
            </p> -->

            <p>
               কারিগরি সহায়তায়:
                   <img style="vertical-align: baseline;" src="site/media/uploads/homepage content/logo_set.png" alt="">
            </p>
            




        </div>
		<!-- /footer -->
	</div>


    <script>


        function setLanguageCookie(cookieValue) {
            var today = new Date();
            var expire = new Date();
            var cookieName = 'lang';
            //var cookieValue = "bn";
            var nDays = 5;
            expire.setTime(today.getTime() + 3600000 * 24 * nDays);
            document.cookie = cookieName + "=" + escape(cookieValue)
                + ";expires=" + expire.toGMTString();
        }

        function setLanguage() {
            $("#lang_form").submit();
            return false;
        }
       
        $(function () {

            // Slideshow 4
            $("#front-image-slider").responsiveSlides({
                auto: true,
                pager: false,
                nav: true,
                speed: 2000,
                maxwidth: 960,
                namespace: "callbacks"
            });
            $("#right-content a").click(function () {
                var url = $(this).attr('href');
                if (isExternal(url) && url != 'javascript:;') {
                    openInNewTab(url);
                    return false;
                }
            });
        });
        function openInNewTab(url) {
            var win = window.open(url, '_blank');
            win.focus();
        }
        function isExternal(url) {
            var match = url.match(/^([^:\/?#]+:)?(?:\/\/([^\/?#]*))?([^?#]+)?(\?[^#]*)?(#.*)?/);
            if (typeof match[1] === "string" && match[1].length > 0 && match[1].toLowerCase() !== location.protocol)
                return true;
            if (typeof match[2] === "string" && match[2].length > 0 && match[2].replace(new RegExp(":(" + {
                        "http:": 80,
                        "https:": 443
                    }[location.protocol] + ")?$"), "") !== location.host)
                return true;
            return false;
        }
    </script>



<script>
    $(function () {


        function initNewsTicker(id, options) {

            var $scroller = $(id);
            $scroller.vTicker('init', options);

            $("#news-ticker .next").click(function (event) {
                event.preventDefault();
                var checked = true;
                $('#news-ticker').vTicker('next', {animate: checked});
            });
            $("#news-ticker .prev,#news-ticker .next").hover(function () {
                $('#news-ticker').vTicker('next', {animate: checked});
                $scroller.vTicker('pause', true);
            }, function () {
                $('#news-ticker').vTicker('next', {animate: checked});
                $scroller.vTicker('pause', false);
            });
            $("#news-ticker .prev").click(function (event) {
                event.preventDefault();
                var checked = true;
                $('#news-ticker').vTicker('prev', {animate: checked});
            });
        }

        function initNoticeBoardTicker(id, options) {

            var $scroller = $(id);
            $scroller.vTicker('init', options);

            $("#notice-board-ticker .next").click(function (event) {
                event.preventDefault();
                var checked = true;
                $('#notice-board-ticker').vTicker('next', {animate: false});
            });
            $("#notice-board-ticker .prev,#notice-board-ticker .next").hover(function () {
                $scroller.vTicker('pause', true);
            }, function () {
                $scroller.vTicker('pause', false);
            });
            $("#notice-board-ticker .prev").click(function (event) {
                event.preventDefault();
                var checked = true;
                $('#notice-board-ticker').vTicker('prev', {animate: checked});
            });
        }

        initNewsTicker('#news-ticker', {});
        //initNoticeBoardTicker('#notice-board-ticker', {showItems:10, margin: 0, padding: 0,animate:false});


    });


    /* Responsive Menu*/


</script>

	
		<!-- Matomo -->
		<script type="text/javascript">
		  var _paq = _paq || [];
		  /* tracker methods like "setCustomDimension" should be called before "trackPageView" */
		  _paq.push(['trackPageView']);
		  _paq.push(['enableLinkTracking']);
		  (function() {
			var u="../external.html?link=https://analytics.portal.gov.bd/piwik/";
			_paq.push(['setTrackerUrl', u+'piwik.php']);
			_paq.push(['setSiteId', 158]);
			var d=document, g=d.createElement('script'), s=d.getElementsByTagName('script')[0];
			g.type='text/javascript'; g.async=true; g.defer=true; g.src=u+'piwik.js'; s.parentNode.insertBefore(g,s);
		  })();
		</script>
	<!-- End Matomo Code -->


<script>
    $(".meganizr .mzr-drop").keyup(function () {

        $(".mzr-content").attr("aria-hidden", "true");
        $(this).find(".mzr-content").attr("aria-hidden", "false");
    });
    // ============ start tile for <a> and alt for img ========
    $('a').each(function () {
        $(this).attr('title', $(this).text());
    });

    var lan = "bn";
    if (lan == 'en') {
        $('.mzr-drop a:first-child').each(function () {
            $(this).attr('title', "Enter to get more menu");
        });
    } else {
        $('.mzr-drop a:first-child').each(function () {
            $(this).attr('title', "সাবমেনুর জন্য ক্লিক করুন");
        });
    }
    $('img').each(function () {
        var str = $(this).attr("src");
        var arr = str.split('index.html');
        var strFine = arr[arr.length - 1];

        var str2 = strFine;
        var arr2 = str2.split('.');
        var strFine2 = arr2[arr2.length - 2];
        $(this).attr('alt', strFine2);
    });
    $('a2iLogo').attr('alt', 'Access to information');
    $('.service-box img').each(function () {
        var strTitle = $(this).parent().find('h4').text();
        $(this).attr('alt', strTitle);
    });
    $('.block img').each(function () {
        var strTitleRight = $(this).closest('.block').find('.title').text();
        $(this).attr('alt', strTitleRight);
    });
    $('#notice-board-ticker .btn').attr('title', 'সকল নোটিশ');
    $('#news-ticker .btn').attr('title', 'সকল খবর');
    $('#search').each(function () {
        $(this).attr('alt', 'Search');
    });
    $('.search-btn').each(function () {
        $(this).attr('alt', 'Enter to search');
    });
    $(".mzr-content").mouseout(function () {
        $(this).hide();
    });
    $(".submenu").mouseover(function () {
        $(this).siblings('.mzr-content').show();
    });
    $(".mzr-content").mouseover(function () {
        $(this).show();
    });
    // ============ end tile for <a> and alt for img ========
</script>

<script>
    $(document).ready(function () {
        $(".slide-panel-button").click(function () {
            $('#domain-selector-panel').toggle()//animate({height: "toggle"}, 200);
            if ($('#domain-selector-panel').is(":visible")) {
                $('#div-lang').css('z-index', '200');
            } else {
                $('#div-lang').css('z-index', '1001');
            }
            $(".slide-panel-button").toggle();
        });

    });
</script>





 <!-- ============ start accessibility megamenu ============ -->

 	<script>

        $(document).ready(function ($) {


            $("#dawgdrops").accessibleMegaMenu({
                /* prefix for generated unique id attributes, which are required
                 to indicate aria-owns, aria-controls and aria-labelledby */
                uuidPrefix: "accessible-megamenu",

                /* css class used to define the megamenu styling */
                menuClass: "meganizr",

                /* css class for a top-level navigation item in the megamenu */
                topNavItemClass: "mzr-drop",

                /* css class for a megamenu panel */
                panelClass: "mzr-content",

                /* css class for a group of items within a megamenu panel */
                panelGroupClass: "mzr-links",

                /* css class for the hover state */
                hoverClass: "hover",

                /* css class for the focus state */
                focusClass: "focus-content",

                /* css class for the open state */
                openClass: "open hover-content"
            });

        });
    </script>


<script>

    $(document).ready(function () {
        var wi = $(window).width();
        if (wi < 769) {
            $('#printable_area td').removeAttr('style');
            $('#printable_area td p').css("width", "100%");
        }
    });
    $( ".meganizr .mzr-drop").keyup(function() {

		$(".mzr-content").attr("aria-hidden","true");
		$(this).find(".mzr-content").attr("aria-hidden", "false");
	});
    // ============ start tile for <a> and alt for img ========
    $('a').each(function() {
        $(this).attr('title', $(this).text());
    });

    var lan = "bn";
    if(lan == 'en'){
        $('.mzr-drop a:first-child').each(function() {
                $(this).attr('title', "Enter to get more menu");
        });
    }else{
        $('.mzr-drop a:first-child').each(function() {
                $(this).attr('title', "সাবমেনুর জন্য ক্লিক করুন");
        });
    }
    $('img').each(function() {
        var str = $(this).attr("src");
        var arr = str.split('index.html');
        var strFine = arr[arr.length-1];

        var str2 = strFine;
        var arr2 = str2.split('.');
        var strFine2 = arr2[arr2.length-2];
        $(this).attr('alt', strFine2);
    });
    $('a2iLogo').attr('alt', 'Access to information');
    $('.service-box img').each(function() {
        var strTitle = $(this).parent().find('h4').text();
        $(this).attr('alt', strTitle);
    });
    $('.block img').each(function() {
        var strTitleRight = $(this).closest('.block').find('.title').text();
        $(this).attr('alt', strTitleRight);
    });
    $('#notice-board-ticker .btn').attr('title', 'সকল নোটিশ');
    $('#news-ticker .btn').attr('title', 'সকল খবর');
    $('#search').each(function() {
        $(this).attr('alt', 'Search');
    });
    $('.search-btn').each(function() {
        $(this).attr('alt', 'Enter to search');
    });
    // ============ end tile for <a> and alt for img ========

    // =============== start dropdown design =======
    $(".mzr-content").mouseout(function(){
       // $(this).hide();
    });
    $(".submenu").mouseover(function(){
        //$('.mzr-content').show();
    });
    $(".mzr-content").mouseover(function(){
        //$(this).show();
    });
    // =============== End dropdown design =======

</script>




</body>


</html>
