<!DOCTYPE html>
<html lang="bn">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>খান অনলাইন পোর্টাল - এক প্ল্যাটফর্মে সব সেবা</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Kalpurush:wght@400;500;600;700&display=swap" rel="stylesheet">
    <script src="https://unpkg.com/lucide@latest/dist/umd/lucide.js"></script>
	<!-- Bootstrap 5 CSS -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            font-family: 'Kalpurush', 'SolaimanLipi', 'Siyam Rupali', Arial, sans-serif !important;
        }
        
        * {
            font-family: 'Kalpurush', 'SolaimanLipi', 'Siyam Rupali', Arial, sans-serif !important;
        }

        .reduced-line-height {
            line-height: 1.3 !important;
        }

        .service-list li {
            line-height: 1.2 !important;
            margin-bottom: 2px !important;
        }

        .notice-list li {
            line-height: 1.25 !important;
            margin-bottom: 3px !important;
        }
    </style>
</head>
<body>

<div class="max-w-6xl mx-auto bg-white shadow-2xl">
    <!-- Top Bar -->
    <div class="bg-purple-800 text-white py-2 border-b-4 border-green-500">
        <div class="container mx-auto px-4">
            <div class="flex flex-col lg:flex-row justify-between items-center text-sm">
                <div class="flex items-center space-x-2 mb-2 lg:mb-0">
                    <i data-lucide="external-link" class="h-4 w-4"></i>
                    <a href="#" target="_blank" rel="noopener noreferrer" 
                       class="hover:text-green-300 transition-colors">
                        বাংলাদেশ জাতীয় তথ্য বাতায়ন
                    </a>
                </div>
                <div class="flex items-center space-x-4">
                    <div class="flex items-center space-x-2">
                        <input 
                            type="text" 
                            placeholder="খুঁজুন..." 
                            class="px-3 py-1 rounded text-gray-800 text-sm w-32 lg:w-40 focus:outline-none focus:ring-2 focus:ring-green-400"
                        />
                        <button class="bg-green-500 hover:bg-green-600 px-3 py-1 rounded transition-colors">
                            <i data-lucide="search" class="h-4 w-4"></i>
                        </button>
                    </div>
                    <button class="border border-white px-3 py-1 rounded hover:bg-white hover:text-purple-800 transition-all">
                        English
                    </button>
                </div>
            </div>
        </div>
    </div>

    <!-- Header -->
    <div class="bg-white shadow-lg">
        <div class="container mx-auto px-4 py-4">
            <div class="flex flex-col lg:flex-row items-center lg:space-x-6">
                <div class="mb-4 lg:mb-0">
                    <img 
                        src="https://i.ibb.co/KKvrj9f/IMG-20240113-WA0016-removebg-preview.png" 
                        alt="Khan Online Portal Logo" 
                        class="h-20 w-auto"
                    />
                </div>
                <div class="text-center lg:text-left">
                    <h1 class="text-2xl lg:text-3xl font-bold text-purple-800 mb-1">
                        খান অনলাইন পোর্টাল
                    </h1>
                    <h2 class="text-lg text-gray-600">
                        এক প্ল্যাটফর্মে সব সেবা
                    </h2>
                </div>
            </div>
        </div>
    </div>
