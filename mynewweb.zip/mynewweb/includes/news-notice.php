<div class="grid gap-4">
    <!-- News Ticker Section -->
    <div id="news-panel" class="bg-gradient-to-r from-gray-50 to-white border border-gray-200 rounded-lg p-4 shadow-lg">
        <div class="flex items-center justify-between mb-3">
            <div class="flex items-center space-x-3">
                <div class="p-1.5 bg-purple-100 rounded-full">
                    <i data-lucide="megaphone" class="h-4 w-4 text-purple-600"></i>
                </div>
                <h2 class="text-base font-bold text-purple-800">সর্বশেষ খবর ও বিজ্ঞপ্তি</h2>
            </div>
            <div class="flex items-center space-x-2">
                <button onclick="toggleNewsPlay()" class="p-1.5 bg-purple-100 hover:bg-purple-200 rounded-full transition-colors">
                    <i data-lucide="pause" class="h-3 w-3 text-purple-600" id="news-play-icon"></i>
                </button>
                <button onclick="previousNews()" class="p-1.5 bg-gray-100 hover:bg-gray-200 rounded-full transition-colors">
                    <i data-lucide="chevron-left" class="h-3 w-3 text-gray-600"></i>
                </button>
                <button onclick="nextNews()" class="p-1.5 bg-gray-100 hover:bg-gray-200 rounded-full transition-colors">
                    <i data-lucide="chevron-right" class="h-3 w-3 text-gray-600"></i>
                </button>
            </div>
        </div>
        
        <div class="bg-white rounded-lg p-3 border-l-4 border-purple-500 shadow-sm">
            <div class="flex items-start space-x-3">
                <i data-lucide="globe" class="w-4 h-4 text-purple-500 mt-0.5 flex-shrink-0"></i>
                <div class="flex-1">
                    <p class="text-gray-800 text-sm leading-snug" id="current-news-text">ডিপ্লোমা-ইন-এগ্রিকালচার শিক্ষাক্রমের ২০২৪-২৫ শিক্ষাবর্ষের ভর্তি প্রক্রিয়া শুরু হবে ১৫ ফেব্রুয়ারি</p>
                    <span class="text-xs text-purple-600 font-medium" id="current-news-date">(২০২৪-০১-২০)</span>
                </div>
            </div>
        </div>
        
        <div class="flex justify-end mt-3">
            <button onclick="showAllNews()" class="inline-flex items-center px-2 py-1 bg-gradient-to-r from-purple-600 to-green-500 text-white rounded-full hover:from-purple-700 hover:to-green-600 transition-all shadow hover:shadow-md text-xs">
                সকল খবর দেখুন
                <i data-lucide="arrow-right" class="h-3 w-3 ml-1"></i>
            </button>
        </div>
    </div>

    <!-- Notice Board Section -->
    <div class="bg-white rounded-lg shadow-lg border border-gray-200">
        <div class="bg-gradient-to-r from-purple-600 to-purple-800 text-white px-4 py-3 rounded-t-lg">
            <div class="flex items-center space-x-3">
                <i data-lucide="clipboard-list" class="h-5 w-5"></i>
                <h2 class="text-lg font-bold">নোটিশ বোর্ড</h2>
            </div>
        </div>
        <div class="p-4">
            <div class="flex items-start space-x-4">
                <div class="flex-shrink-0">
                    <img src="https://images.pexels.com/photos/87651/earth-blue-planet-globe-planet-87651.jpeg" 
                         alt="বিজ্ঞপ্তি"
                         class="w-[120px] h-[120px] object-cover rounded-lg border border-gray-200"/>
                </div>
                
                <div class="flex-1">
                    <div class="space-y-1">
                        <div class="flex items-baseline">
                            <i data-lucide="check-circle" class="w-4 h-4 text-green-500 mr-2 mt-1 flex-shrink-0"></i>
                            <a href="notice-details.php?id=1" class="text-gray-700 hover:text-purple-600 transition-colors text-sm leading-tight block">
                                এইচএসসি (বিএমটি) শিক্ষাক্রমে পাঠদান নবায়ন প্রসঙ্গে
                            </a>
                        </div>
                        <div class="flex items-baseline">
                            <i data-lucide="check-circle" class="w-4 h-4 text-green-500 mr-2 mt-1 flex-shrink-0"></i>
                            <a href="notice-details.php?id=2" class="text-gray-700 hover:text-purple-600 transition-colors text-sm leading-tight block">
                                জাতীয় দক্ষতামান বেসিক (৩৬০ ঘন্টা) শিক্ষাক্রমের জুলাই-সেপ্টেম্বর সেশনের রেজিস্ট্রেশন প্রসঙ্গে
                            </a>
                        </div>
                        <div class="flex items-baseline">
                            <i data-lucide="check-circle" class="w-4 h-4 text-green-500 mr-2 mt-1 flex-shrink-0"></i>
                            <a href="notice-details.php?id=3" class="text-gray-700 hover:text-purple-600 transition-colors text-sm leading-tight block">
                                এসএসসি (ভোকেশনাল) ও দাখিল (ভোকেশনাল) পরীক্ষা-২০২৫ এর কন্ট্রোল রুম খোলা প্রসঙ্গে
                            </a>
                        </div>
                        <div class="flex items-baseline">
                            <i data-lucide="check-circle" class="w-4 h-4 text-green-500 mr-2 mt-1 flex-shrink-0"></i>
                            <a href="notice-details.php?id=4" class="text-gray-700 hover:text-purple-600 transition-colors text-sm leading-tight block">
                                ২০২৪ সনে অনুষ্ঠিত এসএসসি (ভোকেশনাল) পরীক্ষার উত্তরপত্র মূল্যায়ন প্রসঙ্গে
                            </a>
                        </div>
                        <div class="flex items-baseline">
                            <i data-lucide="check-circle" class="w-4 h-4 text-green-500 mr-2 mt-1 flex-shrink-0"></i>
                            <a href="notice-details.php?id=5" class="text-gray-700 hover:text-purple-600 transition-colors text-sm leading-tight block">
                                ডিপ্লোমা ইন ইঞ্জিনিয়ারিং ভর্তি বিজ্ঞপ্তি ২০২৪-২৫
                            </a>
                        </div>
                    </div>
                    <div class="flex justify-end mt-2 pt-2 border-t border-gray-200">
                        <button onclick="showAllNotices()" class="inline-flex items-center px-2 py-1 bg-purple-600 text-white rounded-full hover:bg-purple-700 transition-all shadow hover:shadow-md text-xs">
                            সকল নোটিশ
                            <i data-lucide="arrow-right" class="h-3 w-3 ml-1"></i>
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- News Archive -->
<div id="all-news-archive" class="bg-white rounded-lg shadow-lg border border-gray-200 mb-4 hidden">
    <div class="bg-gradient-to-r from-purple-600 to-purple-800 text-white px-4 py-3 rounded-t-lg">
        <div class="flex items-center justify-between">
            <div class="flex items-center space-x-3">
                <i data-lucide="megaphone" class="h-5 w-5"></i>
                <h2 class="text-lg font-bold">সকল খবর আর্কাইভ</h2>
            </div>
            <button onclick="hideAllNews()" class="text-white hover:text-gray-200">
                <i data-lucide="x" class="h-5 w-5"></i>
            </button>
        </div>
    </div>
    <div class="p-4">
        <div class="space-y-2 max-h-96 overflow-y-auto" id="news-archive-container">
            <!-- News items will be dynamically inserted here -->
        </div>
    </div>
</div>

<!-- Notice Archive -->
<div id="all-notices-archive" class="bg-white rounded-lg shadow-lg border border-gray-200 mb-4 hidden">
    <div class="bg-gradient-to-r from-purple-600 to-purple-800 text-white px-4 py-3 rounded-t-lg">
        <div class="flex items-center justify-between">
            <div class="flex items-center space-x-3">
                <i data-lucide="clipboard-list" class="h-5 w-5"></i>
                <h2 class="text-lg font-bold">সকল নোটিশ আর্কাইভ</h2>
            </div>
            <button onclick="hideAllNotices()" class="text-white hover:text-gray-200">
                <i data-lucide="x" class="h-5 w-5"></i>
            </button>
        </div>
    </div>
    <div class="p-4">
        <div class="space-y-2 max-h-96 overflow-y-auto" id="notice-archive-container">
            <!-- Notice items will be dynamically inserted here -->
        </div>
    </div>
</div>

<script>
// News data
const newsItems = [
    { text: "ডিপ্লোমা-ইন-এগ্রিকালচার শিক্ষাক্রমের ২০২৪-২৫ শিক্ষাবর্ষের ভর্তি প্রক্রিয়া শুরু হবে ১৫ ফেব্রুয়ারি", date: "২০২৪-০১-২০" },
    { text: "এইচএসসি (বিএমটি) পর্যায়ের পরীক্ষার সময়সূচী প্রকাশ", date: "২০২৪-০১-১৮" },
    { text: "কারিগরি শিক্ষা বোর্ডের নতুন ওয়েবসাইট চালু", date: "২০২৪-০১-১৫" },
    { text: "এসএসসি (ভোকেশনাল) পরীক্ষার ফলাফল প্রকাশ ৩০ জানুয়ারি", date: "২০২৪-০১-১০" },
    { text: "ডিপ্লোমা ইন ইঞ্জিনিয়ারিং ভর্তি সংক্রান্ত বিজ্ঞপ্তি", date: "২০২৪-০১-০৫" },
    { text: "জাতীয় দক্ষতা উন্নয়ন কর্মসূচীর রেজিস্ট্রেশন শুরু", date: "২০২৪-০১-০২" },
    { text: "কারিগরি শিক্ষা প্রতিষ্ঠানের নিবন্ধন নবায়ন প্রসঙ্গে", date: "২০২৩-১২-২৮" },
    { text: "শিক্ষক নিয়োগ বিধিমালা সংশোধনী", date: "২০২৩-১২-২৫" },
    { text: "পরীক্ষা কেন্দ্র নির্ধারণ সংক্রান্ত বিজ্ঞপ্তি", date: "২০২৩-১২-২০" },
    { text: "ভর্তি পরীক্ষার প্রবেশপত্র ডাউনলোড", date: "২০২৩-১২-১৫" }
];

// Notice data
const noticeItems = [
    { id: 1, text: "এইচএসসি (বিএমটি) শিক্ষাক্রমে পাঠদান নবায়ন প্রসঙ্গে", date: "২০২৪-০১-২৫" },
    { id: 2, text: "জাতীয় দক্ষতামান বেসিক (৩৬০ ঘন্টা) শিক্ষাক্রমের জুলাই-সেপ্টেম্বর সেশনের রেজিস্ট্রেশন প্রসঙ্গে", date: "২০২৪-০১-২২" },
    { id: 3, text: "এসএসসি (ভোকেশনাল) ও দাখিল (ভোকেশনাল) পরীক্ষা-২০২৫ এর কন্ট্রোল রুম খোলা প্রসঙ্গে", date: "২০২৪-০১-২০" },
    { id: 4, text: "২০২৪ সনে অনুষ্ঠিত এসএসসি (ভোকেশনাল) পরীক্ষার উত্তরপত্র মূল্যায়ন প্রসঙ্গে", date: "২০২৪-০১-১৮" },
    { id: 5, text: "ডিপ্লোমা ইন ইঞ্জিনিয়ারিং ভর্তি বিজ্ঞপ্তি ২০২৪-২৫", date: "২০২৪-০১-১৫" },
    { id: 6, text: "কারিগরি শিক্ষা প্রতিষ্ঠানের নিবন্ধন নবায়ন প্রসঙ্গে", date: "২০২৪-০১-১২" },
    { id: 7, text: "শিক্ষক নিয়োগ বিধিমালা সংশোধনী", date: "২০২৪-০১-১০" },
    { id: 8, text: "পরীক্ষা কেন্দ্র নির্ধারণ সংক্রান্ত বিজ্ঞপ্তি", date: "২০২৪-০১-০৮" },
    { id: 9, text: "ভর্তি পরীক্ষার প্রবেশপত্র ডাউনলোড", date: "২০২৪-০১-০৫" },
    { id: 10, text: "শিক্ষাবর্ষ ২০২৪-২৫ এর একাডেমিক ক্যালেন্ডার", date: "২০২৪-০১-০২" }
];

// Initialize variables
let currentNewsIndex = 0;
let isNewsPlaying = true;
let newsInterval;

// Initialize components
function initComponents() {
    // Initialize news archive
    const newsArchive = document.getElementById('news-archive-container');
    newsItems.forEach(item => {
        newsArchive.innerHTML += `
            <div class="flex items-start space-x-3 p-3 hover:bg-gray-50 rounded-lg transition-colors border-l-4 border-transparent hover:border-purple-400">
                <i data-lucide="calendar" class="w-4 h-4 text-purple-400 mt-1 flex-shrink-0"></i>
                <div class="flex-1">
                    <p class="text-gray-700 text-sm leading-tight">${item.text}</p>
                    <span class="text-xs text-purple-600 font-medium">তারিখ: ${item.date}</span>
                </div>
            </div>
        `;
    });

    // Initialize notice archive
    const noticeArchive = document.getElementById('notice-archive-container');
    noticeItems.forEach(item => {
        noticeArchive.innerHTML += `
            <div class="flex items-start space-x-3 p-3 hover:bg-gray-50 rounded-lg transition-colors border-l-4 border-transparent hover:border-purple-400">
                <i data-lucide="file-text" class="w-4 h-4 text-purple-400 mt-1 flex-shrink-0"></i>
                <div class="flex-1">
                    <a href="notice-details.php?id=${item.id}" class="text-gray-700 hover:text-purple-600 transition-colors text-sm leading-tight block">${item.text}</a>
                    <span class="text-xs text-purple-600 font-medium">প্রকাশিত: ${item.date}</span>
                </div>
            </div>
        `;
    });

    // Set first news
    updateNews();
    
    // Start auto-play
    startNewsInterval();
    
    // Initialize icons
    lucide.createIcons();
}

// Update current news
function updateNews() {
    const newsText = document.getElementById('current-news-text');
    const newsDate = document.getElementById('current-news-date');
    
    if(newsText && newsDate) {
        newsText.textContent = newsItems[currentNewsIndex].text;
        newsDate.textContent = `(${newsItems[currentNewsIndex].date})`;
    }
}

// Next news
function nextNews() {
    currentNewsIndex = (currentNewsIndex + 1) % newsItems.length;
    updateNews();
}

// Previous news
function previousNews() {
    currentNewsIndex = (currentNewsIndex - 1 + newsItems.length) % newsItems.length;
    updateNews();
}

// Toggle play/pause
function toggleNewsPlay() {
    isNewsPlaying = !isNewsPlaying;
    const icon = document.getElementById('news-play-icon');
    
    if(isNewsPlaying) {
        icon.setAttribute('data-lucide', 'pause');
        startNewsInterval();
    } else {
        icon.setAttribute('data-lucide', 'play');
        clearInterval(newsInterval);
    }
    lucide.createIcons();
}

// Start auto-play
function startNewsInterval() {
    clearInterval(newsInterval);
    newsInterval = setInterval(nextNews, 4000);
}

// Show all news
function showAllNews() {
    document.getElementById('news-panel').classList.add('hidden');
    document.getElementById('all-news-archive').classList.remove('hidden');
}

// Hide all news
function hideAllNews() {
    document.getElementById('news-panel').classList.remove('hidden');
    document.getElementById('all-news-archive').classList.add('hidden');
}

// Show all notices
function showAllNotices() {
    document.getElementById('all-notices-archive').classList.remove('hidden');
}

// Hide all notices
function hideAllNotices() {
    document.getElementById('all-notices-archive').classList.add('hidden');
}

// Initialize when DOM is loaded
document.addEventListener('DOMContentLoaded', initComponents);
</script>