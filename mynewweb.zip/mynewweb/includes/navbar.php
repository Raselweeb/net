
    <style>
        /* Reset and Base Styles */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        
        /* Navigation Container */
        .nav {
            background: #f8f8f8;
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
            overflow: visible; /* Crucial for dropdowns */
        }
        
        /* Main Menu */
        .nav > ul {
            display: flex;
            list-style: none;
            align-items: center;
            margin: 0;
            padding: 0;
            position: relative;
        }
        
        /* Menu Items */
        .nav li {
            position: relative;
            border: 1px dotted #ccc;
            margin-right: -1px; /* Remove double borders */
            transition: all 0.3s ease;
        }
        
        .nav li:hover {
            background: #2a7f40; /* Darker green */
        }
        
        /* Menu Links */
        .nav > ul > li > a {
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 12px 20px;
            text-decoration: none;
            color: #333;
            height: 100%;
            transition: all 0.3s ease;
        }
        
        .nav li:hover > a {
            color: white;
        }
        
        /* Home Icon */
        .home-icon {
            width: 50px;
            padding: 0 !important;
        }
        
        .home-icon a {
            padding: 12px !important;
        }
        
        .home-icon-image {
            display: block;
            width: 24px;
            height: 24px;
            background-image: url('https://nctb.gov.bd/themes/responsive_npf/img/home_dark.png');
            background-repeat: no-repeat;
            background-position: center;
            background-size: contain;
            filter: brightness(0.8);
            transition: filter 0.3s ease;
        }
        
        .nav li:hover .home-icon-image {
            filter: brightness(0) invert(1);
        }
        
        /* Dropdown Menu */
        .dropdown {
            position: absolute;
            top:0;
            left: 0;
            background: white;
            min-width: 200px;
            box-shadow: 0 3px 5px rgba(0,0,0,0.2);
            display: none;
            z-index: 1000;
        }
        
        .nav li:hover > .dropdown {
            display: block;
			
        }
        
        .dropdown li {
            border-bottom: 1px dotted #eee;
            text-align: left;
            margin-left:-32px;
            background: white;
          list-style:none;
          padding:5px;
        }
        
        .dropdown li:last-child {
            border-bottom: none;
        }
        
        .dropdown a {
            justify-content: flex-start;
            padding: 10px 20px !important;
            white-space: nowrap;
            color: #333 !important;
          text-decoration:none;
        }
        
        .dropdown li:hover {
            background: #2a7f4 !important;
        }
        
        .dropdown li:hover a {
            color: white !important;
        }
    </style>
</head>
<body>
    <div class="nav">
        <ul>
            <li class="home-icon">
                <a href="http://localhost/mynewproject/" title="মূলপাতা">
                    <span class="home-icon-image"></span>
                </a>
            </li>
            <li>
                <a href="#">পোর্টাল সম্পর্কে</a>
                
            </li>
            <li>
                <a href="#">এনসিটিবি সম্পর্কে</a>
                
            </li>
            <li>
                <a href="#">শিক্ষাক্রম</a>
               
            </li>
            <li>
                <a href="#">পাঠ্যপুস্তক</a>
                
            </li>
            <li><a href="#">শিক্ষক সহয়িকা</a></li>
            <li><a href="#">আইসিটি</a></li>
            
            <li><a href="#">গুরুত্বপূর্ণ ডকুমেন্টস</a></li>
            <li><a href="#">যোগাযোগ</a></li>
        </ul>
    </div>
