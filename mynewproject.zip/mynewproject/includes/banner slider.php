
    <style>
        /* বেসিক রিসেট */
        * { margin: 0; padding: 0; box-sizing: border-box; }
        
        /* স্লাইডার স্টাইল */
        .slider-container {
            max-width: 10;
            margin:0px;
            position: relative;
            overflow: hidden;
            box-shadow: 0 2px 10px rgba(0,0,0,0.2);
        }
        .slider {
            display: flex;
            transition: transform 0.5s ease;
        }
        .slider img {
            width: 100%;
            height: 220px;
            display: block;
        }
        /* নেভিগেশন বাটন */
        .prev, .next {
            position: absolute;
            top: 50%;
            transform: translateY(-50%);
            background: rgba(0,0,0,0.5);
            color: white;
            border: none;
            padding: 10px 15px;
            cursor: pointer;
            z-index: 10;
        }
        .prev { left: 10px; }
        .next { right: 10px; }
    </style>
    <div class="slider-container">
        <div class="slider">
            <img src="https://bteb.gov.bd/sites/default/files/files/bteb.portal.gov.bd/top_banner/7699e582_282e_47e5_b32d_ec8847a6fbc1/banner_5.jpg" alt="ইমেজ ১">
            <img src="https://bteb.gov.bd/sites/default/files/files/bteb.portal.gov.bd/top_banner/5ec989ca_d8e9_46ed_b805_9cba6ce0306b/karigori_2.JPG" alt="ইমেজ ২">
            <img src="https://bteb.gov.bd/sites/default/files/files/bteb.portal.gov.bd/top_banner/ed35ebea_1ddd_429f_815c_754870140d0f/karigori_3.jpg" alt="ইমেজ ৩">
        </div>
        <button class="prev">❮</button>
        <button class="next">❯</button>
    </div>

    <script>
        // ভ্যানিলা JavaScript দিয়ে স্লাইডার লজিক
        const slider = document.querySelector('.slider');
        const images = document.querySelectorAll('.slider img');
        const prevBtn = document.querySelector('.prev');
        const nextBtn = document.querySelector('.next');
        
        let counter = 0;
        const size = images[0].clientWidth;
        
        function slide() {
            slider.style.transform = `translateX(${-size * counter}px)`;
        }
        
        nextBtn.addEventListener('click', () => {
            if (counter >= images.length - 1) counter = -1;
            counter++;
            slide();
        });
        
        prevBtn.addEventListener('click', () => {
            if (counter <= 0) counter = images.length;
            counter--;
            slide();
        });
        
        // অটো-স্লাইড
        setInterval(() => {
            if (counter >= images.length - 1) counter = -1;
            counter++;
            slide();
        }, 3000);
    </script>
