
  <link href="styles.css" rel="stylesheet">
  <link rel="stylesheet" href="styles.css">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

</head>

<body>
  <div class="wrapper">
 <div class="container-wrapper">
   <div class="row">
     <div></div>
   </div>
    <div class="col">
   <div class="row">
     <div class="col-5">
      <div class="row">
        <div class="col-6">খান অনলাইন পোর্টাল</div>
        <div class="col-4">
          <select>
            <option value="Home">অধিদপ্তর সমুহ</option>
            <option value="Home">Home2</option>
            <option value="Home">Home3</option>
            <option value="Home">Home4</option>
            
          </select>
        </div>
        <div class="col-2">
          <button type="submit">GO</button>
        </div>
      </div>
     </div>
    <div class="col-4">
      
    </div>
   <div class="col-3">
    <div class="row">
    <div class="col-5">
      <input type="Placeholder"></input>
    </div>
    <div class="col">
      <button>Search</button>
    </div>
    <div class="col">
      <button>English</button>
    </div>
   </div>
   </div>
   </div>
    </div>
       <div class="row2">
        <div class="col">
         <div class="row">
           <div class="col">
             
           </div>
         </div>
        </div>
       </div>
      <div class="row3">
        <div class="col">
          <div class="row">
           <div class="col">
             
           </div>
         </div>
        </div>
      </div>
       <div class="row4 main-content">
         <div class="col">
         <div class="row">
           <!--service box-->
           <div class="col-9">
             service-box
           </div>
           <!--right sidebar-->
           <div class="col-3">
             side bar
           </div>
         </div>
         </div>
       </div>
      
    <!--menu-->
   
      </div>
    </div>
    
    
