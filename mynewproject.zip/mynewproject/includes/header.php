
<link rel="stylesheet" href="styles.css">


<! -- service -- >
<div class="service-container">
  <!-- Box 1 -->
  <div class="service-box">
    <h3>বিজ্ঞপ্তি</h3>
    <ul>
      <li>▶️ ডিপ্লোমা পর্যায়</li>
      <li>▶️ এইচ এস সি পর্যায়</li>
      <li>▶️ এস,এস,সি পর্যায়</li>
      <li>▶️ সংক্ষিপ্ত মেধাতালিকা ও অন্যান্য</li>
    </ul>
  </div>

  <!-- Box 2 -->
  <div class="service-box">
    <h3>অনলাইনে ভর্তি (সেশনঃ ২০২৪-২০২৫)</h3>
    <img src="https://bteb.gov.bd/sites/default/files/files/bteb.portal.gov.bd/front_service_box/679bbc53_109e_4979_8c69_0987d6b327b1/images.jpg" alt="Apply Now" class="apply-img">
    <ul>
      <li>▶️ সরকারি শিক্ষাপ্রতিষ্ঠানে ভর্তি</li>
      <li>▶️ প্রতিষ্ঠানের তালিকা</li>
      <li>▶️ ভর্তি নীতিমালা</li>
    </ul>
  </div>
  <div class="service-box">
    <h3>বিজ্ঞপ্তি</h3>
    <ul>
      <li>▶️ ডিপ্লোমা পর্যায়</li>
      <li>▶️ এইচ এস সি পর্যায়</li>
      <li>▶️ এস,এস,সি পর্যায়</li>
      <li>▶️ সংক্ষিপ্ত মেধাতালিকা ও অন্যান্য</li>
    </ul>
  </div>
  <div class="service-box">
    <h3>অনলাইনে ভর্তি (সেশনঃ ২০২৪-২০২৫)</h3>
    <img src="https://bteb.gov.bd/sites/default/files/files/bteb.portal.gov.bd/front_service_box/679bbc53_109e_4979_8c69_0987d6b327b1/images.jpg" alt="Apply Now" class="apply-img">
    <ul>
      <li>▶️ সরকারি শিক্ষাপ্রতিষ্ঠানে ভর্তি</li>
      <li>▶️ প্রতিষ্ঠানের তালিকা</li>
      <li>▶️ ভর্তি নীতিমালা</li>
    </ul>
  </div>
  <div class="service-box">
    <h3>বিজ্ঞপ্তি</h3>
    <ul>
      <li>▶️ ডিপ্লোমা পর্যায়</li>
      <li>▶️ এইচ এস সি পর্যায়</li>
      <li>▶️ এস,এস,সি পর্যায়</li>
      <li>▶️ সংক্ষিপ্ত মেধাতালিকা ও অন্যান্য</li>
    </ul>
  </div>
  <div class="service-box">
    <h3>অনলাইনে ভর্তি (সেশনঃ ২০২৪-২০২৫)</h3>
    <img src="https://bteb.gov.bd/sites/default/files/files/bteb.portal.gov.bd/front_service_box/679bbc53_109e_4979_8c69_0987d6b327b1/images.jpg" alt="Apply Now" class="apply-img">
    <ul>
      <li>▶️ সরকারি শিক্ষাপ্রতিষ্ঠানে ভর্তি</li>
      <li>▶️ প্রতিষ্ঠানের তালিকা</li>
      <li>▶️ ভর্তি নীতিমালা</li>
    </ul>
  </div>
</div>
