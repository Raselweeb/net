<!DOCTYPE html>
<html lang="bn">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>খান অনলাইন পোর্টাল - এক প্ল্যাটফর্মে সব সেবা</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Kalpurush:wght@400;500;600;700&display=swap" rel="stylesheet">
    <script src="https://unpkg.com/lucide@latest/dist/umd/lucide.js"></script>
	<!-- Bootstrap 5 CSS -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            font-family: 'Kalpurush', 'SolaimanLipi', 'Siyam Rupali', Arial, sans-serif !important;
        }
        
        * {
            font-family: 'Kalpurush', 'SolaimanLipi', 'Siyam Rupali', Arial, sans-serif !important;
        }

        .reduced-line-height {
            line-height: 1.3 !important;
        }

        .service-list li {
            line-height: 1.2 !important;
            margin-bottom: 2px !important;
        }

        .notice-list li {
            line-height: 1.25 !important;
            margin-bottom: 3px !important;
        }
    </style>
</head>
<!-- Navigation -->
<div class="bg-gray-100 border-t border-b border-gray-200 sticky top-0 z-50">
    <div class="container mx-auto px-4">
        <div class="lg:hidden">
            <button
                onclick="toggleMobileMenu()"
                class="w-full bg-purple-800 text-white py-3 px-4 flex items-center justify-between font-semibold"
            >
                মেনু নির্বাচন করুন
                <i data-lucide="menu" class="h-5 w-5" id="menu-icon"></i>
            </button>
        </div>
        
        <nav id="main-nav" class="hidden lg:block">
            <ul class="flex flex-col lg:flex-row lg:items-center">
                <li class="border-r border-dotted border-gray-400">
                    <a href="/" class="flex items-center justify-center px-3 py-2 text-gray-700 hover:bg-cyan-100 hover:text-cyan-800 transition-all group">
                        <div class="relative">
                            <i data-lucide="smartphone-nfc" class="h-5 w-5 transition-all group-hover:scale-110 group-hover:text-cyan-600"></i>
                            <div class="absolute -inset-2 bg-cyan-200 rounded-full opacity-0 group-hover:opacity-30 transition-opacity"></div>
                        </div>
                    </a>
                </li>
                <li class="relative group border-r border-dotted border-gray-400">
                    <a href="#" class="flex items-center justify-between px-3 py-2 text-gray-700 transition-all text-sm hover:bg-blue-100 hover:text-blue-800 lg:cursor-default">
                        আমাদের সম্পর্কে
                        <i data-lucide="chevron-down" class="h-3 w-3 ml-1 transition-transform lg:group-hover:rotate-180"></i>
                    </a>
                    <ul class="lg:absolute lg:top-full lg:left-0 bg-white lg:border lg:border-gray-200 lg:shadow-xl w-full lg:w-64 opacity-0 lg:group-hover:opacity-100 invisible lg:group-hover:visible transition-all duration-300 z-50 hidden">
                        <li><a href="#" class="flex items-center px-3 py-1.5 text-gray-600 hover:bg-purple-50 hover:text-purple-800 border-b border-gray-100 transition-all text-sm reduced-line-height">
                            <i data-lucide="check-circle" class="h-3 w-3 mr-2 text-green-500"></i>ইতিহাস</a></li>
                        <li><a href="#" class="flex items-center px-3 py-1.5 text-gray-600 hover:bg-purple-50 hover:text-purple-800 border-b border-gray-100 transition-all text-sm reduced-line-height">
                            <i data-lucide="check-circle" class="h-3 w-3 mr-2 text-green-500"></i>অবকাঠামো</a></li>
                        <li><a href="#" class="flex items-center px-3 py-1.5 text-gray-600 hover:bg-purple-50 hover:text-purple-800 border-b border-gray-100 transition-all text-sm reduced-line-height">
                            <i data-lucide="check-circle" class="h-3 w-3 mr-2 text-green-500"></i>কার্যক্রম</a></li>
                        <li><a href="#" class="flex items-center px-3 py-1.5 text-gray-600 hover:bg-purple-50 hover:text-purple-800 border-b border-gray-100 transition-all text-sm reduced-line-height">
                            <i data-lucide="check-circle" class="h-3 w-3 mr-2 text-green-500"></i>পরিচালনা পর্ষদ</a></li>
                        <li><a href="#" class="flex items-center px-3 py-1.5 text-gray-600 hover:bg-purple-50 hover:text-purple-800 transition-all text-sm reduced-line-height">
                            <i data-lucide="check-circle" class="h-3 w-3 mr-2 text-green-500"></i>কর্মকর্তা বৃন্দ</a></li>
                    </ul>
                </li>
                <li class="relative group border-r border-dotted border-gray-400">
                    <a href="#" class="flex items-center justify-between px-3 py-2 text-gray-700 transition-all text-sm hover:bg-green-100 hover:text-green-800 lg:cursor-default">
                        পাঠ্যক্রম
                        <i data-lucide="chevron-down" class="h-3 w-3 ml-1 transition-transform lg:group-hover:rotate-180"></i>
                    </a>
                    <ul class="lg:absolute lg:top-full lg:left-0 bg-white lg:border lg:border-gray-200 lg:shadow-xl w-full lg:w-64 opacity-0 lg:group-hover:opacity-100 invisible lg:group-hover:visible transition-all duration-300 z-50 hidden">
                        <li><a href="#" class="flex items-center px-3 py-1.5 text-gray-600 hover:bg-purple-50 hover:text-purple-800 border-b border-gray-100 transition-all text-sm reduced-line-height">
                            <i data-lucide="check-circle" class="h-3 w-3 mr-2 text-green-500"></i>ডিপ্লোমা পর্যায়</a></li>
                        <li><a href="#" class="flex items-center px-3 py-1.5 text-gray-600 hover:bg-purple-50 hover:text-purple-800 border-b border-gray-100 transition-all text-sm reduced-line-height">
                            <i data-lucide="check-circle" class="h-3 w-3 mr-2 text-green-500"></i>এইচ এস সি পর্যায়</a></li>
                        <li><a href="#" class="flex items-center px-3 py-1.5 text-gray-600 hover:bg-purple-50 hover:text-purple-800 border-b border-gray-100 transition-all text-sm reduced-line-height">
                            <i data-lucide="check-circle" class="h-3 w-3 mr-2 text-green-500"></i>এস,এস,সি পর্যায়</a></li>
                        <li><a href="#" class="flex items-center px-3 py-1.5 text-gray-600 hover:bg-purple-50 hover:text-purple-800 transition-all text-sm reduced-line-height">
                            <i data-lucide="check-circle" class="h-3 w-3 mr-2 text-green-500"></i>সল্প মেয়াদী ও অন্যান্য</a></li>
                    </ul>
                </li>
                <li class="relative group border-r border-dotted border-gray-400">
                    <a href="#" class="flex items-center justify-between px-3 py-2 text-gray-700 transition-all text-sm hover:bg-orange-100 hover:text-orange-800 lg:cursor-default">
                        শিক্ষকদের তথ্য
                        <i data-lucide="chevron-down" class="h-3 w-3 ml-1 transition-transform lg:group-hover:rotate-180"></i>
                    </a>
                    <ul class="lg:absolute lg:top-full lg:left-0 bg-white lg:border lg:border-gray-200 lg:shadow-xl w-full lg:w-64 opacity-0 lg:group-hover:opacity-100 invisible lg:group-hover:visible transition-all duration-300 z-50 hidden">
                        <li><a href="#" class="flex items-center px-3 py-1.5 text-gray-600 hover:bg-purple-50 hover:text-purple-800 border-b border-gray-100 transition-all text-sm reduced-line-height">
                            <i data-lucide="check-circle" class="h-3 w-3 mr-2 text-green-500"></i>ডিপ্লোমা লেভেল</a></li>
                        <li><a href="#" class="flex items-center px-3 py-1.5 text-gray-600 hover:bg-purple-50 hover:text-purple-800 border-b border-gray-100 transition-all text-sm reduced-line-height">
                            <i data-lucide="check-circle" class="h-3 w-3 mr-2 text-green-500"></i>এইচ এস সি লেভেল</a></li>
                        <li><a href="#" class="flex items-center px-3 py-1.5 text-gray-600 hover:bg-purple-50 hover:text-purple-800 border-b border-gray-100 transition-all text-sm reduced-line-height">
                            <i data-lucide="check-circle" class="h-3 w-3 mr-2 text-green-500"></i>এস এস সি লেভেল</a></li>
                        <li><a href="#" class="flex items-center px-3 py-1.5 text-gray-600 hover:bg-purple-50 hover:text-purple-800 transition-all text-sm reduced-line-height">
                            <i data-lucide="check-circle" class="h-3 w-3 mr-2 text-green-500"></i>সল্প মেয়াদী ও অন্যান্য</a></li>
                    </ul>
                </li>
                <li class="border-r border-dotted border-gray-400">
                    <a href="#" class="flex items-center justify-between px-3 py-2 text-gray-700 transition-all text-sm hover:bg-purple-100 hover:text-purple-800">
                        প্রকাশনা
                    </a>
                </li>
                <li class="border-r border-dotted border-gray-400">
                    <a href="#" class="flex items-center justify-between px-3 py-2 text-gray-700 transition-all text-sm hover:bg-red-100 hover:text-red-800">
                        রেজাল্ট
                    </a>
                </li>
                <li class="border-r border-dotted border-gray-400">
                    <a href="#" class="flex items-center justify-between px-3 py-2 text-gray-700 transition-all text-sm hover:bg-indigo-100 hover:text-indigo-800">
                        ডাউনলোড
                    </a>
                </li>
                <li>
                    <a href="#" class="flex items-center justify-between px-3 py-2 text-gray-700 transition-all text-sm hover:bg-teal-100 hover:text-teal-800">
                        ই-সেবা
                    </a>
                </li>
            </ul>
        </nav>
    </div>
</div>

<style>
    /* Navigation specific styles */
    .reduced-line-height {
        line-height: 1.2;
    }
    
    /* Mobile menu styles */
    @media (max-width: 1023px) {
        #main-nav ul {
            display: none;
        }
        
        #main-nav.block ul {
            display: block;
        }
        
        .relative.group ul {
            position: static;
            box-shadow: none;
            border: none;
            width: auto;
            opacity: 1;
            visibility: visible;
            display: none;
            padding-left: 1rem;
        }
        
        .relative.group ul.show {
            display: block;
        }
    }
</style>

<script>
    function toggleMobileMenu() {
        const nav = document.getElementById('main-nav');
        const icon = document.getElementById('menu-icon');
        
        if (nav.classList.contains('hidden')) {
            nav.classList.remove('hidden');
            nav.classList.add('block');
            icon.setAttribute('data-lucide', 'x');
        } else {
            nav.classList.add('hidden');
            nav.classList.remove('block');
            icon.setAttribute('data-lucide', 'menu');
            
            // Close all submenus when closing main menu
            document.querySelectorAll('.group ul').forEach(submenu => {
                submenu.classList.remove('show');
            });
        }
        lucide.createIcons();
    }

    // Handle submenu toggle on mobile
    function setupMobileSubmenus() {
        const submenuToggles = document.querySelectorAll('.group > a');
        
        submenuToggles.forEach(toggle => {
            toggle.addEventListener('click', function(e) {
                if (window.innerWidth >= 1024) return;
                
                e.preventDefault();
                const submenu = this.nextElementSibling;
                const isOpen = submenu.classList.contains('show');
                
                // Close all other submenus first
                document.querySelectorAll('.group ul').forEach(menu => {
                    if (menu !== submenu) menu.classList.remove('show');
                });
                
                // Toggle current submenu
                if (isOpen) {
                    submenu.classList.remove('show');
                } else {
                    submenu.classList.add('show');
                }
            });
        });
    }

    // Initialize
    document.addEventListener('DOMContentLoaded', function() {
        lucide.createIcons();
        setupMobileSubmenus();
        
        // Handle resize events
        window.addEventListener('resize', function() {
            if (window.innerWidth >= 1024) {
                // On desktop, ensure all submenus are hidden (they'll show on hover)
                document.querySelectorAll('.group ul').forEach(submenu => {
                    submenu.classList.remove('show');
                });
            }
        });
    });
</script>