
<div class="footer-artwork" id="footer-artwork">&nbsp;</div>
<div class="footer-full-width">
  <div class="footer-menu">
    <ul>
      <li><a href="#">Home</a></li>
      <li><a href="#">About me</a></li>
      <li><a href="#">Services</a></li>
      <li><a href="#">Prices</a></li>
      <li><a href="#">Contact</a></li>
    </ul>
  </div>
  <div class="footer-creadit">
  <P>পরিকল্পনা ও বাস্তবায়নে:  মন্ত্রিপরিষদ বিভাগ,  এটুআই,  বিসিসি,  ডিওআইসিটি ও  বেসিস।</P>
  <span>কারিগরি সহায়তায়</span><img src="https://bteb.gov.bd/themes/responsive_npf/img/np-logo-set.png" width="210px"height="auto">
  </div>
  <span><i>সাইটটি শেষ হাল-নাগাদ করা হয়েছে: ২০২৫-০৬-১৯ ১৭:৩৪:২২ </i></span>
  
</div>