﻿
<link rel="stylesheet" href="styles.css">
<div class="sec-area">
        <div class="r-sec-title">মাননীয় শিক্ষা উপদেষ্টা</div>
        <img src="https://images.unsplash.com/photo-1575936123452-b67c3203c357?w=500&auto=format&fit=crop&q=60&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Mnx8aW1hZ2V8ZW58MHx8MHx8fDA%3D" width="100%">
      <h4><b>মাননীয় শিক্ষা উপদেষ্টা</b></h4>
	  <span>বিস্তারিত</span>
	  </div>
      <div class="sec-area">
        <div class="r-sec-title">HSC</div>
     <img src="https://images.unsplash.com/photo-1575936123452-b67c3203c357?w=500&auto=format&fit=crop&q=60&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Mnx8aW1hZ2V8ZW58MHx8MHx8fDA%3D" width="100%">
      </div>
      <div class="sec-area">
        <div class="r-sec-title">SSC</div>
      </div>
      <div class="sec-area">
        <div class="r-sec-title">JSX</div>
      </div>
      <div class="sec-area">
        <div class="r-sec-title">PSC</div>
      </div>
      <div class="sec-area">
        <div class="r-sec-title">One</div>
      </div>
