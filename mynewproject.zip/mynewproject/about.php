<?php include 'includes/header.php'; ?>
<?php include 'includes/slider.php'; ?>
<?php include 'includes/sidebar.php'; ?>

<main>
  <h2>সার্ভিসেস</h2>
  <p>আমরা যেসব সেবা দিয়ে থাকি...</p>
</main>

<?php include 'includes/footer.php'; ?>
