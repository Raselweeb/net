
 
﻿﻿<!DOCTYPE html>
<!--[if lt IE 7 ]>
<html class="ie ie6" lang="en"> <![endif]-->
<!--[if IE 7 ]>
<html class="ie ie7" lang="en"> <![endif]-->
<!--[if IE 8 ]>
<html class="ie ie8" lang="en"> <![endif]-->
<!--[if (gte IE 9)|!(IE)]><!-->
<html lang="en" xmlns="http://www.w3.org/1999/html">
<!--<![endif]-->

<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <!-- Online Polling -->
    <script src="//polling.portal.gov.bd/js/npop.script.js" defer></script>
    <!-- Comment Management Tools -->
    <script src="//polling.portal.gov.bd/js/npc.script.js" defer></script>
    <!-- userway accessibility start -->
    <!-- <script type="text/javascript">
      var _userway_config = {
      account: "xyS2BuGIbM"
      };
  </script>
  <script type="text/javascript" src="https://cdn.userway.org/widget.js"></script> -->
    <!-- userway accessibility end -->

        <title>বাংলাদেশ কারিগরি শিক্ষা বোর্ড-গণপ্রজাতন্ত্রী বাংলাদেশ সরকার</title>
    <!-- Mobile Specific Metas
    ================================================== -->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="X-Frame-Options" content="deny">
        <meta name="description" content="">

    <!-- =============== tt canonical End =============================== -->

        <link type="text/css" rel="stylesheet" media="all" href="/themes/responsive_npf/stylesheets/base.css" /><link type="text/css" rel="stylesheet" media="all" href="/themes/responsive_npf/stylesheets/skeleton.css" /><link type="text/css" rel="stylesheet" media="all" href="/themes/responsive_npf/stylesheets/style.css" /><link type="text/css" rel="stylesheet" media="all" href="/themes/responsive_npf/stylesheets/meganizr.css" /><link type="text/css" rel="stylesheet" media="all" href="/npfadmin/public/css/flaticon/flaticon.css" /><link type="text/css" rel="stylesheet" media="all" href="/themes/responsive_npf/templates/ministry/style.css" />
    <!--<script type="text/javascript" src="//ajax.googleapis.com/ajax/libs/jquery/1.6.0/jquery.min.js"></script>-->
    <script type="text/javascript" src="//code.jquery.com/jquery-1.11.1.min.js"></script>

    <!-- include the jquery-accessibleMegaMenu plugin script -->
    <script src="/themes/responsive_npf/js/jquery-accessibleMegaMenu.js"></script>


    <script>
        //jq160 = jQuery.noConflict( true );
    </script>
    
    <link rel="stylesheet" href="/themes/responsive_npf/stylesheets/responsiveslides.css">

    <link rel="stylesheet" href="/themes/responsive_npf/templates/ministry/responsive.css">
    <link rel="stylesheet" href="/themes/responsive_npf/templates/ministry/accessibility.css">
    <script src="/themes/responsive_npf/js/responsiveslides.min.js"></script>
    <script src="/themes/responsive_npf/js/jquery.vticker.js" type="text/javascript"></script>

    <script src="/themes/responsive_npf/js/domain_selector.js" type="text/javascript"></script>
    <script src="/themes/responsive_npf/js/utils.js" type="text/javascript"></script>
    <script type="text/javascript" src="/themes/responsive_npf/js/yoxview/yoxview-init.js"></script>


    <!-- custom accessibility start -->
    <link rel="stylesheet" href="/accessibility/css/asb.css">
    <script src="/accessibility/js/asb.js" type="text/javascript"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.9.0/css/all.min.css" />
    <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.9.0/js/all.min.js"></script>
    <!-- accessibility active issues -->

    <!-- <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script> -->
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    <script>
        document.addEventListener('keyup', (event) => {
            //var name = event.key; //var code = event.code;
            if (event.code === "Tab") {
                var k = 0;
                if (event.shiftKey) {
                    //shift+tab pressed//Code // console.log(event.target);
                    var activeElement = document.activeElement;
                    if (activeElement.tagName.toLowerCase() == 'button') {
                        if (activeElement.title === 'Download Screen Reader') {
                            $('#myModalClose').attr('id', 'myModal');
                            $('#myModal').modal();
                            return false;
                        }
                    }
                } else {
                    //only tab pressed //Code
                }
            }

        });

        //====================//
        // Add event listener on keydown
        var access = 0;
        if (access === 0) {
            document.addEventListener('keyup', (event) => {
                var name = event.key;
                var code = event.code;
                var i = 0;
                if (code == "Tab" && i == 0) {
                    $('#myModal').modal();
                    i = i + 1;
                }
                // Alert the key name and key code on keydown
            });
            var accessibilitypop = document.querySelector('#accessibilitypop');

            function accessibility() {
                $('#myModal').modal('hide');
                document.getElementById("universalAccessBtn").click();
                $('#myModal').attr('id', 'myModalClose');
                //$('#accessibilityBar').attr('class', 'active');
                $('#myModal').attr('tabindex', '');
                document.getElementById("universalAccessBtn").focus();
                $('#accessibilityBar').attr('role', 'dialog');
                $('#universalAccessBtn').attr('tabindex', '1');
            };

            function accessibilitySkipToMainContent() {
                $('#myModal').attr('tabindex', '');
                $('#myModal').attr('id', 'myModalClose');
                $('#notice-board-bg').attr({
                    'aria-selected': true,
                    'tabindex': 0
                });
                //$('#skip-main-content-start-here').attr({'aria-selected': true, 'tabindex': '-1'});
                document.getElementById("skip-main-content-start-here").focus();
            }

            function accessibilitymodelClose() {
                //$('#notice-board-bg').attr('tabindex', '0');
                $('#skip-main-content-start-here').attr('tabindex', '0');
                $('#myModal').attr('tabindex', '');
                $('#myModal').attr('id', 'myModalClose');
            }

        }

        function start_np() {
            $('#start-np').attr({
                'aria-selected': true,
                'tabindex': 0
            });
            document.getElementById("start-np").focus();
        }
    </script>
    <style>
        #accessibilityBar button#universalAccessBtn {
            border-radius: 0px !important;
        }

        #accessibilityBar {
            top: 360px !important;
        }

        .btn-for-accessibility {
            font-size: 13px;
            background: local;
        }
    </style>
    <!-- end accessibility active issues -->
    <!-- custom accessibility end -->

</head>

<body class="bteb-portal-gov-bd">
    <!-- accessibility Modal -->
    <div class="modal fade" id="myModal" role="dialog" tabindex="-1" style="display: none;margin: -10px 0 8px 0;text-align: center;">
        <div class="modal-dialog text-center">
            <!-- Modal content-->
            <div class="modal-content">
                <div class="modal-body">
                    <button class="btn-for-accessibility" data-dismiss="modal" onclick="accessibilitymodelClose()">Skip to main content</button>
                    <button class="btn-for-accessibility" id="accessibilitypop" onclick="accessibility()">Go to accessibility menu</button>
                    <button class="btn-for-accessibility close" type="button" data-dismiss="modal" onclick="accessibilitymodelClose()">&times;</button>
                </div>
            </div>

        </div>
    </div>
    <!--   -->
    <!-- ====== start jump to selections ======   -->
    <a class="skip-link" href="/accessibility.html" target="_blank">Accessibility
        Help</a>
    <a class="skip-link" href="#jmenu">Jump to Menu</a>
    <a class="skip-link" href="#contents">Jump to Content</a>
    <a class="skip-link" href="#search">Jump to Search</a>
    <a class="skip-link" href="#btnLang">Jump to Language</a>
    <!-- ====== End jump to selections ======   -->


    <div class="container">
        <div id="start-np" autofocus="autofocus" style="opacity:0;font-size:1px;position: absolute;" aria-selected="true" tabindex="0">Wellcome to National Portal</div>

        ﻿<script src="//bangladesh.gov.bd/nav/js/obd.main.js?v=1.0.1"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/select2/4.0.5/js/select2.js"></script>
<link rel="stylesheet" media="all" type="text/css" href="//bangladesh.gov.bd/nav/css/obd.main.css">



<div class="sixteen columns"
	style="background-color: #683091; box-shadow: 0 1px 5px #999999;height:40px;margin-top: -20px;">
	<div style="display: inline-block;float: left;width: 960px;border-bottom: 4px solid #8bc643;">
		<div class="slide-panel-btns" style="width: 165px;float: left;">
							<div class="slide-panel-button" style="display: block;">
					<!-- <i class="flaticon-menu10" style="float: left"></i> -->
					<a style="color: white;height:100%;font-size:.9em;margin-top: 7px;" href="http://www.bangladesh.gov.bd/"
						target="_blank">বাংলাদেশ জাতীয় তথ্য বাতায়ন</a>
				</div>
						</div>
		<div id="div-lang" style="float:left;width: 795px;height: 32px;">
			<div id="newNavigation"></div>
			<div id="div-lang-sel" style="float: right">

				<div id="search_any" style="float: left">
					<div style="margin-top: 5px;padding: 0;float: left;">
						<input style="width:90px;border-radius: 4px;height: 18px;" id="search_val" name="key"
							value="" />
						<button class="search-btn" type="button" style="margin: 0;padding: 1px 10px"
							id="search-button">Search</button>
					</div>
					<script>
						// Function to redirect to Google with search query
						function redirectToGoogle() {
							var input = document.getElementById('search_val').value;
							var searchQuery = encodeURIComponent(input);
							var site_url = window.location.origin;
							var site_link = ("https://www.google.com/search?q=" + searchQuery + " " + site_url);

							if (searchQuery != '') {
								window.open(site_link, '_blank');
							} else {
								alert(`যা খুঁজতে চান তা লিখুন`);
							}
						}

						// Event listener for Enter key press
						document.getElementById('search_val').addEventListener('keydown', function (e) {
							if (e.key === 'Enter') {
								redirectToGoogle();
							}
						});

						// Event listener for search button click
						document.getElementById('search-button').addEventListener('click', redirectToGoogle);
					</script>
				</div>

				<div style="float: left;margin-left: 5px">
					<form id="lang_form" action="/" method="post">
																			<input type="hidden" name="lang" id="lang" value="en" />
							<button type="submit" style="padding: 2px;margin-top:5px">English</button>
												</form>
				</div>
			</div>
		</div>
	</div>
</div>



<div class="sixteen columns">
	<div class="callbacks_container" style="box-shadow: 0 1px 5px #999999;">
		<ul class="rslides" id="front-image-slider">
	    	<li>
    		                        <img src="//bteb.gov.bd/sites/default/files/files/bteb.portal.gov.bd/top_banner/7699e582_282e_47e5_b32d_ec8847a6fbc1/banner_5.jpg" alt="" width="960" height="220"/>   
                		
    	       	</li>
	    	<li>
    		                        <img src="//bteb.gov.bd/sites/default/files/files/bteb.portal.gov.bd/top_banner/5ec989ca_d8e9_46ed_b805_9cba6ce0306b/karigori_2.JPG" alt="" width="960" height="220"/>   
                		
    	       	</li>
	    	<li>
    		                        <img src="//bteb.gov.bd/sites/default/files/files/bteb.portal.gov.bd/top_banner/ed35ebea_1ddd_429f_815c_754870140d0f/karigori_3.jpg" alt="" width="960" height="220"/>   
                		
    	       	</li>
	</ul><style>.rslides img{height:220px}
.cabinet-portal-gov-bd .meganizr>li>a{font-size:18px!important}

</style><script></script>	</div>


	<div class="header-site-info" id="header-site-info">

		<div>

			<div id="logo">
								<a title="Home" href="/">
					<img alt="Home" src="/themes/responsive_npf/img/logo/logo.png">
				</a>

			</div>

			<div class="clearfix" id="site-name-wrapper">
				<span id="site-name">
					<a title="Home" href="/">
						বাংলাদেশ কারিগরি শিক্ষা বোর্ড					</a>
				</span>
				<span id="slogan">
					গণপ্রজাতন্ত্রী বাংলাদেশ সরকার				</span>
			</div>
			<!-- /site-name-wrapper -->

		</div>
		<!-- /header-site-info-inner -->

	</div>

</div>
	﻿<script>
            /* Responsive Design*/
            $(document).ready(function () {
				var wi = $( window ).width();
                if(wi < 980){
                    
					$('#jmenu .show-menu').click(function () {
						//$('.mzr-responsive').show();
						$(".mzr-responsive").slideToggle(400,"linear", function () {
                            
						});
					});
		  
                    $("#jmenu a.submenu").click(function() {
                        
                      $('#jmenu a.submenu').siblings().addClass('sibling-toggle');
                      $(this).parent().find(".mzr-content").removeClass('sibling-toggle').addClass('slide-visible').slideToggle(400,"linear", function() {
                        return false;
                      });
                      // return false;
                    });
                }

                $('.submenu').addClass('sub-menu');
                $('.mzr-drop').addClass('focusin-drop');
                $('.mzr-drop').addClass('focusClassDrop');
            });
            
        </script>
      
  
        <div class="sixteen columns" id="jmenu">
            <div class="sixteen columns menu">

               <a href="javascript:;" class="show-menu menu-head"> মেনু নির্বাচন করুন</a>
                <div role="navigation" id="dawgdrops">
                    <ul class="meganizr mzr-slide mzr-responsive" >
                        <!-- Build The Menu -->
                        <li class="col0 "><a title="Home" href="/" style="background-image: url(/themes/responsive_npf/img/home_dark.png);margin-top:5px;"></a></li><li class="col1 mzr-drop"><a href="#" class="submenu">আমাদের সম্পর্কে</a><div class="mzr-content drop-one-columns"><div class="one-col"><h6> </h6><ul class="mzr-links"><li><a href="http://bteb.portal.gov.bd/sites/default/files/files/bteb.portal.gov.bd/page/e01325e6_1fd0_4d3f_ab80_d5c22fa4074d/Alternate%20Officers.pdf">বিভাগীয় প্রধানদের বিকল্প কর্মকর্তা</a></li><li><a href="http://bteb.portal.gov.bd/site/page/e92398ac-76ee-427c-85d4-a3c6d500d725">ইতিহাস</a></li><li><a href="http://bteb.portal.gov.bd/site/page/87456cd9-b0ac-448c-a6f8-42585f74456b">অবকাঠামো</a></li><li><a href="http://bteb.portal.gov.bd/site/page/f03beeac-8402-44f9-a2ac-ea52d7c1ff6d">কার্যক্রম</a></li><li><a href="/site/page/acd2a1d9-79b0-4d80-9980-2e61a3f9ae94/পরিচালনা-পর্ষদ">পরিচালনা পর্ষদ</a></li><li><a href="/site/view/officer_list_category/চেয়ারম্যানের_দপ্তর/কর্মকর্তা-বৃন্দ-(জ্যেষ্ঠতার-ভিত্তিতে-নয়)">কর্মকর্তা বৃন্দ (জ্যেষ্ঠতার ভিত্তিতে নয়)</a></li><li><a href="/site/view/staff_list//কর্মচারীবৃন্দ-(জ্যেষ্ঠতার-ভিত্তিতে-নয়)">কর্মচারীবৃন্দ (জ্যেষ্ঠতার ভিত্তিতে নয়)</a></li><li><a href="https://bteb.portal.gov.bd/sites/default/files/files/bteb.portal.gov.bd/page/34a0070d_360b_4180_93ea_d4946900876b/Final%20Citizen%20Charter%28BTEB%29.pdf">সিটিজেন চার্টার</a></li><li><a href="https://bteb.portal.gov.bd/sites/default/files/files/bteb.portal.gov.bd/page/f53e8e32_192b_4b9d_b1cd_a08bfad0c4b3/Focal%20Point%20%2823-10-2024%29.pdf">সকল ফোকাল পয়েন্ট</a></li></ul></div></div></li><li class="col2 mzr-drop"><a class="submenu" href="https://drive.google.com/folderview?id=0BynIJ2cATXt3NmxhWC1JTDd3RHc&amp;usp=sharing">পাঠ্যক্রম</a><div class="mzr-content drop-one-columns"><div class="one-col"><h6></h6><ul class="mzr-links"><li><a href="http://bteb.gov.bd/site/page/6723ed9b-94d5-41a9-80cf-54a3594a171e">ডিপ্লোমা পর্যায়</a></li><li><a href="http://bteb.gov.bd/site/page/6723ed9b-94d5-41a9-80cf-54a3594a171e">এইচ এস সি পর্যায়</a></li><li><a href="http://bteb.gov.bd/site/page/6723ed9b-94d5-41a9-80cf-54a3594a171e">এস,এস,সি পর্যায়</a></li><li><a href="http://bteb.gov.bd/site/page/6723ed9b-94d5-41a9-80cf-54a3594a171e">সল্প মেয়াদী ও অন্যান্য</a></li></ul></div></div></li><li class="col3 mzr-drop"><a href="#" class="submenu">শিক্ষকদের তথ্য</a><div class="mzr-content drop-one-columns"><div class="one-col"><h6></h6><ul class="mzr-links"><li><a href="http://103.197.207.70:8666/dip_teacher/index.php">ডিপ্লোমা লেভেল</a></li><li><a href="http://103.197.207.70:8666/hscbmvoc_teacher/">এইচ এস সি লেভেল</a></li><li><a href="http://www.bteb.gov.bd/site/page/378c2f42-e751-4c74-b884-e97835d9fe63/Teacher-List-%E0%A6%8F%E0%A6%A8%E0%A7%8D%E0%A6%9F%E0%A7%8D%E0%A6%B0%E0%A6%BF">এস এস সি লেভেল</a></li><li><a href="http://103.197.207.70:8444/basic_teacher/index.php">সল্প মেয়াদী ও অন্যান্য</a></li><li><a href="http://103.197.207.70:8444/textile_teacher/index.php">ডিপ্লোমা ইন টেক্সটাইল</a></li><li><a href="http://103.197.207.70:8444/agriculture_teacher/">ডিপ্লোমা ইন এগ্রিকালচার ও ফিসারীজ</a></li></ul></div></div></li><li class="col4 mzr-drop"><a class="submenu" href="https://drive.google.com/folderview?id=0BynIJ2cATXt3NmxhWC1JTDd3RHc&amp;usp=sharing">প্রকাশনা</a><div class="mzr-content drop-one-columns"><div class="one-col"><h6></h6><ul class="mzr-links"><li><a href="https://bteb.portal.gov.bd/site/page/2c4c1ed1-3853-4ab3-98cd-4c005524c2eb">গবেষণা প্রতিবেদন</a></li><li><a href="https://bteb.portal.gov.bd/site/page/620d7fdf-b0e2-40c2-b193-d15efbe912ba">বার্ষিক প্রতিবেদন</a></li><li><a href="http://www.bteb.gov.bd/site/page/96b954f5-495a-43e4-a27b-66229f7c560a">পাঠ্যবই</a></li></ul></div></div></li><li class="col5 mzr-drop"><a class="submenu" href="http://"> রেজাল্ট </a><div class="mzr-content drop-one-columns"><div class="one-col"><h6></h6><ul class="mzr-links"><li><a href="http://180.211.162.102:8444/result_arch/index.php">ডিপ্লোমা ইঞ্জিনিয়ারিং</a></li><li><a href="http://180.211.162.102:8444/result_arch/index.php">ডিপ্লোমা এগ্রি</a></li><li><a href="http://www.educationboardresults.gov.bd">এইচ এস সি পর্যায়</a></li><li><a href="http://www.educationboardresults.gov.bd">বিএম/ডিকম</a></li><li><a href="http://www.educationboardresults.gov.bd">এস এস সি পর্যায়</a></li><li><a href="http://180.211.162.102:8444/result_arch/index.php">সল্পমেয়াদী ও অন্যান্য</a></li></ul></div></div></li><li class="col6 mzr-drop"><a href="#" class="submenu">ডাউনলোড</a><div class="mzr-content drop-one-columns"><div class="one-col"><h6></h6><ul class="mzr-links"><li><a href="http://bteb.gov.bd/site/page/6723ed9b-94d5-41a9-80cf-54a3594a171e">সিলেবাস/কোর্স স্ট্রাকচার/প্রবিধান</a></li><li><a href="http://www.bteb.gov.bd/site/page/4df44549-07e8-42ef-800d-4e7fe0981836">ফরমসমূহ</a></li><li><a href="http://www.bteb.gov.bd/site/page/14fc21a0-8a2d-400f-8e20-5fbd989a68f5">একাডেমিক ক্যালেন্ডার</a></li><li><a href="http://www.bteb.gov.bd/site/page/f15b9974-45a8-4b5e-aed8-8f8af4025f12">আইন/বিধি/নীতিমালা</a></li><li><a href="https://drive.google.com/drive/folders/1oBz0ZkqXdp9u2Cf-mdQZHIqQCF410TSn?usp=sharing">কারিগরি শিক্ষক নির্দেশিকা</a></li></ul></div></div></li><li class="col7 "><a class="submenu" href="http://www.btebcbt.gov.bd/">QAIR ওয়েবসাইট</a></li><li class="col8 "><a class="submenu" href="https://btebesheba.gov.bd/">ই-সেবা</a></li><li class="col9 "><a class="submenu" href="https://bteb.portal.gov.bd/sites/default/files/files/bteb.portal.gov.bd/page/34a0070d_360b_4180_93ea_d4946900876b/Citizen%20Charter%20%282%29.pdf">তথ্য প্রাপ্তির জন্য যোগাযোগ</a></li><li class="col10 "><a class="submenu" href="https://bteb.portal.gov.bd/site/page/d0f7e639-bbc0-4740-8380-55073fef0623">পলিটেকনিকসমূহ</a></li><li class="col11 "><a class="submenu" href="https://bteb.portal.gov.bd/site/page/5a0921a8-9346-4fe3-8367-9e2bd92f0021">টেকনিক্যাল স্কুল ও কলেজসমূহ</a></li><li class="col12 "><a class="submenu" href="https://bteb.gov.bd/site/page/5ee5e5aa-5d37-4930-bc75-e6ad3e2dc4a5">স্বল্পমেয়াদী কোর্স প্রতিষ্ঠানসমূহ</a></li><li class="col13 "><a class="submenu" href="https://bteb.gov.bd/site/page/0e48034b-1c29-4099-967e-867ea55926b9">প্রজ্ঞাপন/পরিপত্র</a></li>                    </ul>
                </div>
            </div>
        </div>
<style>
	.right-side-bar .block ul li a {
		font-size: 14px;
	}

	#notice-board ul a {
		font-size: 14px;
	}

	@media screen and (min-width: 1400px) {
		.mainwrapper .box {
			margin-right: 13px
		}
	}
</style>



        <div id="contents" class="sixteen columns">
            <div class="twelve columns" id="left-content">
                                <div class="row mainwrapper">
                    <div style=" background-color: #EFEFEF;border: 1px solid #CCCCCC;margin-bottom: 20px;padding: 10px;" class="row" id="news">
	<h5 style="float:left;margin:-3px 5px 0 0; font-weight:bold;font-size:.9em">খবর:</h5>
	<div id="news-ticker" style="overflow: hidden; position: relative; height: 0px;">
		<ul style="font-size: 0.9em; position: absolute; margin: 0px; padding: 0px; width: 95%;">
				<li class="lineheight"><a href="/site/news/059a9ebf-84d9-440b-827d-b39e0f3b9a1f/ডিপ্লোমা-ইন-এগ্রিকালচার-ফিসারিজ-লাইভস্টক-ফরেস্ট্রিও-ডিপ্লোমা-ইন-টেক্সটাইল-ইঞ্জিনিয়ারিং-শিক্ষাক্রমের-২০২৪-২৫-শিক্ষাবর্ষের-১ম-পর্বের-ক্লাস-আগামী-৩০-জানুয়ারি-২০২৫-তারিখে-শুরু-হবে">ডিপ্লোমা-ইন-এগ্রিকালচার/ফিসারিজ/লাইভস্টক/ফরেস্ট্রিও ডিপ্লোমা-ইন-টেক্সটাইল ইঞ্জিনিয়ারিং শিক্ষাক্রমের ২০২৪-২৫ শিক্ষাবর্ষের ১ম পর্বের ক্লাস আগামী ৩০ জানুয়ারি ২০২৫ তারিখে শুরু হবে</a> <i>(&#x09E8;&#x09E6;&#x09E8;&#x09EB;-&#x09E6;&#x09E7;-&#x09E8;&#x09EF;)</i></li>   
 	<li class="lineheight"><a href="/site/news/999967f7-763a-4607-82b3-b22136542638/২০২৫-সনের-এইচএসসি-বিএম-বিএমটি-ভোকেশনাল-ও-ডিপ্লোমা-ইন-কমার্স-শিক্ষাক্রমের-১ম-ও-২য়-বর্ষের-পাঠদানকারী-শিক্ষকদের-তালিকা-অনলাইনে-প্রেরণ-হালনাগাদ-এর-বিজ্ঞপ্তি">২০২৫ সনের এইচএসসি (বিএম-বিএমটি, ভোকেশনাল) ও ডিপ্লোমা ইন কমার্স শিক্ষাক্রমের ১ম ও ২য় বর্ষের পাঠদানকারী শিক্ষকদের তালিকা অনলাইনে প্রেরণ-হালনাগাদ-এর বিজ্ঞপ্তি</a> <i>(&#x09E8;&#x09E6;&#x09E8;&#x09EB;-&#x09E6;&#x09E7;-&#x09E7;&#x09E8;)</i></li>   
 	<li class="lineheight"><a href="/site/news/11906882-7ad6-4e0b-9b2a-c323d01f6f0c/এসএসসি-ও-দাখিল-ভোকেশনাল-শিক্ষাক্রমের-রেজিস্ট্রেশনকৃত-শিক্ষার্থীদের-ছবি-চেক-করুন।-ছবি-না-বা-ভুল-থাকলে-অব্যার্থভাবে-২২-১১-২০২৪-খ্রি-এর-মধ্যে-আপডেট-করুন।-অনাকাংখিত-সমস্যার-জন্য-আন্তরিকভাবে দুঃখিত।">এসএসসি ও দাখিল (ভোকেশনাল) শিক্ষাক্রমের রেজিস্ট্রেশনকৃত শিক্ষার্থীদের ছবি চেক করুন। ছবি না বা ভুল থাকলে অব্যার্থভাবে ২২-১১-২০২৪ খ্রি. এর মধ্যে আপডেট করুন। অনাকাংখিত সমস্যার জন্য আন্তরিকভাবে দুঃখিত।</a> <i>(&#x09E8;&#x09E6;&#x09E8;&#x09EA;-&#x09E7;&#x09E7;-&#x09E8;&#x09E6;)</i></li>   
 		</ul>
		<div style="float:right">
			<a class="btn" href="/site/view/news">সকল</a>
		</div>
	</div>
</div><style>.lineheight{
	line-height: 22px;
}</style><script></script><div class="row" id="notice-board">
	<div class="notice-board-bg">
		<h2>নোটিশ বোর্ড</h2>
		<div id="notice-board-ticker">
			<ul>
								<li>
					<a href="/site/notices/f6ab9b32-d095-4de0-9280-bd14c1eb6887/ডিপ্লোমা-ইন-ইঞ্জিনিয়ারিং-শিক্ষাক্রমের-পরীক্ষার-ফরম-ফিলাপের-সময়-বৃদ্ধি-সংক্রান্ত-বিজ্ঞ">ডিপ্লোমা ইন ইঞ্জিনিয়ারিং শিক্ষাক্রমের পরীক্ষার ফরম ফিলাপের সময় বৃদ্ধি সংক্রান্ত বিজ্ঞ...</a>				</li>
								<li>
					<a href="/site/notices/637b531f-196d-4be5-aec5-bf601481c4d4/দ্বৈত-সনদায়ন-সংক্রান্ত-বিজ্ঞপ্তি">দ্বৈত সনদায়ন সংক্রান্ত বিজ্ঞপ্তি</a>				</li>
								<li>
					<a href="/site/notices/9089d20a-70f7-4804-8e07-0a4b6b4f5e6f/এইচএসসি-বিএম-বিএমটি-এইচএসসি-ভোক-ডিপ্লোমা-ইন-কমার্স-চূড়ান্ত-পরীক্ষা-২০২৫-এর-কন্ট">এইচএসসি (বিএম/বিএমটি), এইচএসসি (ভোক.) ডিপ্লোমা-ইন-কমার্স চূড়ান্ত পরীক্ষা-২০২৫ এর কন্ট...</a>				</li>
								<li>
					<a href="/site/notices/099af2af-3ffd-4349-85c3-4d27e02225df/করোনা-ভাইরাস-এবং-ডেঙ্গু-রোগের-সংক্রমণ-হারের-ঊর্ধ্বগতি-বিবেচনায়-এইচএসসি-বিএম-বিএমটি-">করোনা ভাইরাস এবং ডেঙ্গু রোগের সংক্রমণ হারের ঊর্ধ্বগতি বিবেচনায় এইচএসসি (বিএম/বিএমটি, ...</a>				</li>
								<li>
					<a href="/site/notices/a5d16f3a-45e1-4e9d-bccd-3148c034ee34/ডিপ্লোমা-ইন-ইঞ্জিনিয়ারিং-শিক্ষাক্রমের-পাঠদানকারী-প্রতিষ্ঠানের-চলমান-পর্বসমূহের-শিক্">ডিপ্লোমা-ইন-ইঞ্জিনিয়ারিং শিক্ষাক্রমের পাঠদানকারী প্রতিষ্ঠানের (চলমান পর্বসমূহের) শিক্...</a>				</li>
							</ul>
			<a class="btn right" href="/site/view/notices">সকল</a>
		</div>
	</div>
</div><style>#notice-board-ticker ul li{
	list-style:none;
}</style><script></script>
		<div class="row">
		<div id="box-1" class="six columns service-box box" >
		<h4>বিজ্ঞপ্তি</h4>
				
		<ul class="caption fade-caption" style="margin:0">
			<li><a href="/site/page/7cd7fa7f-4960-483c-b4e2-5404721ac62b/ডিপ্লোমা-পর্যায়">ডিপ্লোমা পর্যায়</a></li>
			<li><a href="/site/page/6270e5cb-d8f0-41a6-ad59-05539c431ad0/এইচ-এস-সি-পর্যায়">এইচ এস সি পর্যায়</a></li>
			<li><a href="/site/page/95facee1-de0b-4c09-b3ff-f35d9811d5d0/এস,এস,সি-পর্যায়">এস,এস,সি পর্যায়</a></li>
			<li><a href="/site/page/648435ff-5974-4b83-a9cc-24f45c103109/সল্প-মেয়াদী-ও-অন্যান্য">সল্প মেয়াদী ও অন্যান্য</a></li>
			
		</ul>
	</div>
			<div id="box-2" class="six columns service-box box" >
		<h4>অনলাইনে ভর্তি (সেশনঃ ২০২৪-২০২৫) </h4>
		<img src="//bteb.gov.bd/sites/default/files/files/bteb.portal.gov.bd/front_service_box/679bbc53_109e_4979_8c69_0987d6b327b1/images.jpg" alt="" width="110" height=""/>		
		<ul class="caption fade-caption" style="margin:0">
			<li><a href="http://www.btebadmission.gov.bd/">সরকারি ও বেসরকারি সকল শিক্ষাক্রমে ভর্তি</a></li>
			<li><a href="https://bteb.portal.gov.bd/site/page/1e71c906-bbfc-43e2-bda1-f4f436b03110">প্রতিষ্ঠানের তালিকা</a></li>
			<li><a href="/site/page/e4b1b646-53b4-46f1-ab39-21c909937b7c/ভর্তির-নীতিমালা">ভর্তির নীতিমালা</a></li>
			<li><a href=""></a></li>
			
		</ul>
	</div>
		</div>
			<div class="row">
		<div id="box-3" class="six columns service-box box" >
		<h4>ই-সেবা (অনলাইন সেবা প্রদান)</h4>
				
		<ul class="caption fade-caption" style="margin:0">
			<li><a href="https://btebesheba.gov.bd/btebapp/r/bteb/bteb-online/basic-information">শিক্ষার্থী তথ্য সংশোধন</a></li>
			<li><a href="https://btebesheba.gov.bd/btebapp/r/portal/bteb-institute/login">ই-সেবা প্রতিষ্ঠান প্যানেল</a></li>
			<li><a href="https://btebesheba.gov.bd/btebapp/f?p=1000">ই-সেবা বাকাশিবো প্যানেল</a></li>
			<li><a href="https://www.mygov.bd/services?category=sector&data=service-sector-67">বিদেশগামী নাগরিকদের সার্টিফিকেট সত্যয়ন</a></li>
			
		</ul>
	</div>
			<div id="box-4" class="six columns service-box box" >
		<h4>ফর্ম ফিলআপ</h4>
		<img src="//bteb.gov.bd/sites/default/files/files/bteb.portal.gov.bd/front_service_box/0e03ee70_4d6d_47f8_8a9a_e2570b49c740/form2.jpg" alt="" width="110" height=""/>		
		<ul class="caption fade-caption" style="margin:0">
			<li><a href="/site/page/c14cacbd-560b-4e82-9b62-f52a90338367/ডিপ্লোমা-পর্যায়">ডিপ্লোমা পর্যায়</a></li>
			<li><a href="/site/page/c14cacbd-560b-4e82-9b62-f52a90338367/এইচ-এস-সি-পর্যায়">এইচ এস সি পর্যায়</a></li>
			<li><a href="/site/page/c14cacbd-560b-4e82-9b62-f52a90338367/এস,এস,সি-পর্যায়">এস,এস,সি পর্যায়</a></li>
			<li><a href="/site/page/c14cacbd-560b-4e82-9b62-f52a90338367/সল্প-মেয়াদী-ও-অন্যান্য">সল্প মেয়াদী ও অন্যান্য</a></li>
			
		</ul>
	</div>
		</div>
			<div class="row">
		<div id="box-4" class="six columns service-box box" >
		<h4>ইনস্টিটিউট কর্ণার</h4>
		<img src="//bteb.gov.bd/sites/default/files/files/bteb.portal.gov.bd/front_service_box/7e3930d8_164f_473b_9e23_b3cedc804f76/cropped_Q1rxzl1hpu_1_r3i9qo (1).png" alt="" width="110" height=""/>		
		<ul class="caption fade-caption" style="margin:0">
			<li><a href="http://103.23.41.226/sschschome/index.php/Login">ইনস্টিটিউট লগইন (এসএসসি ও এইচএসসি পর্যায়)</a></li>
			<li><a href="http://103.23.41.229/diplomaall/index.php/Login">ইনস্টিটিউট লগইন (ডিপ্লোমা ও সার্টিফিকেট পর্যায়)</a></li>
			<li><a href=""></a></li>
			<li><a href=""></a></li>
			
		</ul>
	</div>
			<div id="box-5" class="six columns service-box box" >
		<h4>অনলাইন তথ্য প্রেরণ/গ্রহণ</h4>
		<img src="//bteb.gov.bd/sites/default/files/files/bteb.portal.gov.bd/front_service_box/feb11667_ee0d_4c4a_b1e5_36c94919bbce/number.jpg" alt="" width="110" height=""/>		
		<ul class="caption fade-caption" style="margin:0">
			<li><a href="/site/page/2d2783b7-4d9d-4a08-9cca-f2e8fe08441f/ডিপ্লোমা-পর্যায়">ডিপ্লোমা পর্যায়</a></li>
			<li><a href="/site/page/3aae8d07-862b-4c85-8f93-4aec030b49ab/TC-PC-PF-IA-মার্ক-ও-GPA-এন্ট্রি">TC/PC/PF/IA মার্ক ও GPA এন্ট্রি</a></li>
			<li><a href="/site/page/773efd8c-1b7d-405b-8e56-3bddbaa02b03/Center-Examinee-&-Absent-Expelled-তথ্য-প্রেরণ">Center Examinee & Absent/Expelled তথ্য প্রেরণ</a></li>
			<li><a href="/site/page/378c2f42-e751-4c74-b884-e97835d9fe63/Institute-Account-এবং-Teacher-List-এন্ট্রি">Institute Account এবং Teacher List এন্ট্রি</a></li>
			
		</ul>
	</div>
		</div>
			<div class="row">
		<div id="box-6" class="six columns service-box box" >
		<h4>চলমান ফলাফল</h4>
		<img src="//bteb.gov.bd/sites/default/files/files/bteb.portal.gov.bd/front_service_box/ca91e6e3_20ed_4a51_a619_99f571da07a7/result.png" alt="" width="110" height=""/>		
		<ul class="caption fade-caption" style="margin:0">
			<li><a href="/site/page/46ea7fc6-2f18-48d8-a313-a377046a1323/ডিপ্লোমা-পর্যায়">ডিপ্লোমা পর্যায়</a></li>
			<li><a href="/site/page/1330ac55-e8d0-41ac-91fa-9aa08657e8c6/এইচ-এস-সি-পর্যায়">এইচ এস সি পর্যায়</a></li>
			<li><a href="/site/page/eac741d5-90c3-4cd1-a791-75de19206699/এস,এস,সি-পর্যায়">এস,এস,সি পর্যায়</a></li>
			<li><a href="/site/page/3a1fe0aa-5ba2-48b1-b082-83fac57e9fb0/সল্প-মেয়াদী-ও-অন্যান্য">সল্প মেয়াদী ও অন্যান্য</a></li>
			
		</ul>
	</div>
			<div id="box-7" class="six columns service-box box" >
		<h4>উত্তরপত্র পুণঃনিরীক্ষণ/স্থগিত ফলাফল</h4>
		<img src="//bteb.gov.bd/sites/default/files/files/bteb.portal.gov.bd/front_service_box/09e63f5c_e76b_4d43_b853_208ac331dd14/images.jpg" alt="" width="110" height=""/>		
		<ul class="caption fade-caption" style="margin:0">
			<li><a href="/site/page/3b6dfb09-5288-4523-9fa1-c8835e0348b6/ডিপ্লোমা-পর্যায়">ডিপ্লোমা পর্যায়</a></li>
			<li><a href="/site/page/3b6dfb09-5288-4523-9fa1-c8835e0348b6/এইচ-এস-সি-পর্যায়">এইচ এস সি পর্যায়</a></li>
			<li><a href="/site/page/3b6dfb09-5288-4523-9fa1-c8835e0348b6/এস,এস,সি-পর্যায়">এস,এস,সি পর্যায়</a></li>
			<li><a href="/site/page/3b6dfb09-5288-4523-9fa1-c8835e0348b6/সল্প-মেয়াদী-ও-অন্যান্য">সল্প মেয়াদী ও অন্যান্য</a></li>
			
		</ul>
	</div>
		</div>
			<div class="row">
		<div id="box-8" class="six columns service-box box" >
		<h4>জব প্লেসমেন্ট</h4>
		<img src="//bteb.gov.bd/sites/default/files/files/bteb.portal.gov.bd/front_service_box/949bce7d_0a20_4218_a203_7d31b2247f4b/JOB.jpg" alt="" width="110" height=""/>		
		<ul class="caption fade-caption" style="margin:0">
			<li><a href=""></a></li>
			<li><a href=""></a></li>
			<li><a href=""></a></li>
			<li><a href=""></a></li>
			
		</ul>
	</div>
			<div id="box-9" class="six columns service-box box" >
		<h4>বার্ষিক কর্মসম্পাদন চুক্তি</h4>
		<img src="//bteb.gov.bd/sites/default/files/files/bteb.portal.gov.bd/front_service_box/009b547b_cf63_4293_a6ac_31c31c9e40be/apa_cab.png" alt="" width="110" height=""/>		
		<ul class="caption fade-caption" style="margin:0">
			<li><a href="/site/page/f6c2ea9a-ea44-4860-acc7-c40eb799976a/এপিএ-প্রকাশনা-নির্দেশিকা-পরিপত্র-এপিএ-টীম-">এপিএ প্রকাশনা/নির্দেশিকা/পরিপত্র/এপিএ টীম </a></li>
			<li><a href="/site/page/358d2584-abd5-40f7-bb7f-a396a41ff5ee/চুক্তিসমূহ">চুক্তিসমূহ</a></li>
			<li><a href="/site/page/1465e7d8-e3c6-4b00-8953-100bf094be13/পরিবীক্ষণ-ও-মূল্যায়ন-প্রতিবেদন">পরিবীক্ষণ ও মূল্যায়ন প্রতিবেদন</a></li>
			<li><a href="/site/page/a8c0a26e-679e-4f35-823b-ad8e9497e63c/বার্ষিক-ক্রয়-পরিকল্পনা-দরপত্র">বার্ষিক ক্রয় পরিকল্পনা/দরপত্র</a></li>
			
		</ul>
	</div>
		</div>
			<div class="row">
		<div id="box-10" class="six columns service-box box" >
		<h4>অন্যান্য সেবা ও পরিসংখ্যান</h4>
		<img src="//bteb.gov.bd/sites/default/files/files/bteb.portal.gov.bd/front_service_box/bd13681f_9e80_47f6_95c1_4525a0042c90/others2.jpg" alt="" width="110" height=""/>		
		<ul class="caption fade-caption" style="margin:0">
			<li><a href="https://bteb.portal.gov.bd/sites/default/files/files/bteb.portal.gov.bd/page/87842e15_d4ae_4185_8909_e051e704e260/BTEB%20Diploma%20Level%20Exam%20Conduct%20Policy%20-%202017.pdf">পরীক্ষা নিয়মনীতি (ডিপ্লোমা)  </a></li>
			<li><a href="https://bteb.portal.gov.bd/sites/default/files/files/bteb.portal.gov.bd/page/87842e15_d4ae_4185_8909_e051e704e260/BTEB%20%E0%A6%AA%E0%A6%B0%E0%A7%80%E0%A6%95%E0%A7%8D%E0%A6%B7%E0%A6%BE%E0%A6%B0%20%E0%A6%A8%E0%A7%80%E0%A6%A4%E0%A6%BF%E0%A6%AE%E0%A6%BE%E0%A6%B2%E0%A6%BE%20-%20%E0%A7%A8%E0%A7%A6%E0%A7%A7%E0%A7%A8.pdf">পরীক্ষা নিয়মনীতি (অন্যান্য)  </a></li>
			<li><a href="/site/page/c587c056-dc08-49b7-8608-713bcec8fba9/পরিসংখ্যান">পরিসংখ্যান</a></li>
			<li><a href=""></a></li>
			
		</ul>
	</div>
			<div id="box-11" class="six columns service-box box" >
		<h4>অভিযোগ প্রতিকার ব্যবস্থাপনা</h4>
		<img src="//bteb.gov.bd/sites/default/files/files/bteb.portal.gov.bd/front_service_box/45e31e19_9ab9_418c_91ef_93f2554635ce/10.png" alt="" width="110" height=""/>		
		<ul class="caption fade-caption" style="margin:0">
			<li><a href="/site/page/b2febb94-d80c-43b4-8828-0f3b2ee45755/অনিক-ও-আপিল-কর্মকর্তাগণ">অনিক ও আপিল কর্মকর্তাগণ</a></li>
			<li><a href="https://bteb.portal.gov.bd/site/page/b8166d4d-a5f6-4ac5-b626-dfb1125d5153">মাসিক/ত্রৈমাসিক/বার্ষিক পরিবীক্ষণ/মূল্যায়ন প্রতিবেদন</a></li>
			<li><a href="http://www.grs.gov.bd/">অভিযোগ দাখিল (অনলাইনে আবেদন)</a></li>
			<li><a href="/site/page/bfeb130f-ad0b-45cb-a6b5-095efd24279b/আইন-বিধি-নীতিমালা-নির্দেশিকা">আইন/বিধি/নীতিমালা/নির্দেশিকা</a></li>
			
		</ul>
	</div>
		</div>
			<div class="row">
		<div id="box-12" class="six columns service-box box" >
		<h4>জাতীয় শুদ্ধাচার কৌশল </h4>
		<img src="//bteb.gov.bd/sites/default/files/files/bteb.portal.gov.bd/front_service_box/093d5961_995b_4f32_a126_3b9216a09c3a/nis_logo3.png" alt="" width="110" height=""/>		
		<ul class="caption fade-caption" style="margin:0">
			<li><a href="/site/page/ecbc200b-9849-4795-be7c-79894eb9f798/শুদ্ধাচার-কৌশল-কর্মপরিকল্পনা">শুদ্ধাচার কৌশল কর্মপরিকল্পনা</a></li>
			<li><a href="/site/page/36bc36af-3675-40b9-8be4-4c50c2323aa1/ফোকাল-পয়েন্ট-কর্মকর্তা-ও-বিকল্প-কর্মকর্তা-">ফোকাল পয়েন্ট কর্মকর্তা ও বিকল্প কর্মকর্তা </a></li>
			<li><a href="/site/page/dfbfe834-cc44-4b1b-8740-dce4a2608d24/ত্রৈমাসিক-ষান্মষিক-পরিবীক্ষণ-মূল্যায়ন-প্রতিবেদন">ত্রৈমাসিক/ষান্মষিক পরিবীক্ষণ/মূল্যায়ন প্রতিবেদন</a></li>
			<li><a href="/site/page/ba64bf85-a885-4ed2-9b96-2da6812dc052/প্রজ্ঞাপন-নীতিমালা-পরিপত্র">প্রজ্ঞাপন/নীতিমালা/পরিপত্র</a></li>
			
		</ul>
	</div>
			<div id="box-13" class="six columns service-box box" >
		<h4>উদ্ভাবনী কার্যক্রম</h4>
		<img src="//bteb.gov.bd/sites/default/files/files/bteb.portal.gov.bd/front_service_box/1a168f2a_88a1_4117_aab3_1755c62dad38/INNOVATION (1).png" alt="" width="110" height=""/>		
		<ul class="caption fade-caption" style="margin:0">
			<li><a href="site\page/0878b61c-41a7-4b4c-a42e-4bf41614b1b5">প্রজ্ঞাপন/পরিপত্র/নীতিমালা/ সংকলন</a></li>
			<li><a href="/site/page/2cb061d6-e661-4d1f-a8b6-9ed16e63a9fb/ইনোভেশন-টিম">ইনোভেশন টিম</a></li>
			<li><a href="/site/page/ea3b736c-0f87-4602-b2f2-1bc1232d70de/বার্ষিক-উদ্ভাবন-কর্মপরিকল্পনা">বার্ষিক উদ্ভাবন কর্মপরিকল্পনা</a></li>
			<li><a href="/site/page/a455e00b-3040-43d5-b173-049b7edae58a/উদ্ভাবনী-প্রকল্পসমূহ">উদ্ভাবনী প্রকল্পসমূহ</a></li>
			
		</ul>
	</div>
		</div>
			<div class="row">
		<div id="box-14" class="six columns service-box box" >
		<h4>তথ্য অধিকার</h4>
		<img src="//bteb.gov.bd/sites/default/files/files/bteb.portal.gov.bd/front_service_box/33030661_72c9_4836_881a_986a7366ce71/info.png" alt="" width="110" height=""/>		
		<ul class="caption fade-caption" style="margin:0">
			<li><a href="/site/page/de4bc888-2113-4e1f-962d-6aeab452169f/দায়িত্বপ্রাপ্ত-কর্মকর্তা-ও-আপীল-কর্তৃপক্ষ">দায়িত্বপ্রাপ্ত কর্মকর্তা ও আপীল কর্তৃপক্ষ</a></li>
			<li><a href="/site/page/e12e5a6b-feee-4f1c-b417-2f1daed51c1f/আবেদন-ও-আপীল-ফরম">আবেদন ও আপীল ফরম</a></li>
			<li><a href="/site/page/489a6f31-a16a-4eb1-a577-2a592e6d5f47/স্বপ্রণোদিতভাবে-প্রকাশযোগ্য-তথ্যসমূহ">স্বপ্রণোদিতভাবে প্রকাশযোগ্য তথ্যসমূহ</a></li>
			<li><a href="/site/page/8680e701-0834-4e1d-bbbd-2aef7bb3612d/আইন-বিধি-নীতিমালা-পরিপত্র-নির্দেশিকা-প্রজ্ঞাপন">আইন/বিধি/নীতিমালা/পরিপত্র/নির্দেশিকা/প্রজ্ঞাপন</a></li>
			
		</ul>
	</div>
			<div id="box-16" class="six columns service-box box" >
		<h4>সেবা প্রদান প্রতিশ্রুতি (সিটিজেন্‌স চার্টার)</h4>
		<img src="//bteb.gov.bd/sites/default/files/files/bteb.portal.gov.bd/front_service_box/3f5a0acc_53fb_498f_acbd_e695619f2220/Service.png" alt="" width="110" height=""/>		
		<ul class="caption fade-caption" style="margin:0">
			<li><a href="/site/page/b9171199-295c-4fdb-b59b-0d6d914e4fff/সেবা-প্রদান-প্রতিশ্রুতি-">সেবা প্রদান প্রতিশ্রুতি </a></li>
			<li><a href="/site/page/87e14711-7da5-4b18-a3b9-3b5bb92d00f7/ফোকাল-পয়েন্ট-কর্মকর্তা-পরীবীক্ষন-কমিটি">ফোকাল পয়েন্ট কর্মকর্তা/পরীবীক্ষন কমিটি</a></li>
			<li><a href="/site/page/108dd5d9-4a70-4907-83bd-73e4b601ac44/ত্রৈমাসিক-বার্ষিক-পরীবীক্ষণ-মূল্যায়ন-প্রতিবেদন">ত্রৈমাসিক/বার্ষিক পরীবীক্ষণ/মূল্যায়ন প্রতিবেদন</a></li>
			<li><a href="/site/page/e3000924-636f-45f4-9de7-d93378018d4d/আইন-বিধি-নীতিমালা-পরিপত্র">আইন/বিধি/নীতিমালা/পরিপত্র</a></li>
			
		</ul>
	</div>
		</div>
			<div class="row">
		<div id="box-17" class="six columns service-box box" >
		<h4>হেল্প ডেস্ক</h4>
				
		<ul class="caption fade-caption" style="margin:0">
			<li><a href="/site/page/b5b36240-0fb4-4781-a0d7-1b808b307184/কম্পিউটার-সেল-(01550620604)">কম্পিউটার সেল (01550620604)</a></li>
			<li><a href="/site/page/22ba71b9-e143-413b-a318-f823f5332d5b/ই-সেবা-হেল্পডেস্ক-(01322-830279)">ই-সেবা হেল্পডেস্ক (01322-830279)</a></li>
			<li><a href="/site/page/10d08195-2788-4546-ba8a-efcd433c4b72/ভর্তি-কার্যক্রম-হেল্পডেস্ক-(01322-830308,-01322-830309)">ভর্তি কার্যক্রম হেল্পডেস্ক (01322-830308, 01322-830309)</a></li>
			<li><a href=""></a></li>
			
		</ul>
	</div>
		</div>
	<style></style><script></script><div class="column block">
	<h5 class="bk-org title">
  		ভিডিও গ্যালেরী  	</h5>
  
  <p>
    </p>
</div>
<style>
#right-content .block { display:block !important}
</style>
<script>
</script><div class="column block">
	<h5 class="bk-org title">
  		ভিডিও গ্যালারি ২  	</h5>
  
  <p>
    </p>
</div>
<style>
#right-content .block { display:block !important}
</style>
<script>
</script>                </div>
            </div>
            <div class="four columns right-side-bar" id="right-content">
                <div class="column block">
	<h5 class="bk-org title">
	<p>মাননীয় শিক্ষা উপদেষ্টা</p>
	
	
	</h5>
<p class="imgcenterofficehead">	
	<img src="//bteb.gov.bd/sites/default/files/files/bteb.portal.gov.bd/office_head/da821081_9b67_4766_8895_0bfebd65eb78/abrar.jpg" alt="" width="100" height=""/></p>
	<p><span style="font-family:arial,helvetica,sans-serif; font-size:inherit">অধ্যাপক ড. চৌধুরী রফিকুল ...
	<p>
		<a href="/site/office_head/9e8a2004-c9b6-4d40-a2dc-a5492f44a805/বিস্তারিত">বিস্তারিত</a>	</p>
</div>
<div class="column block">
	<h5 class="bk-org title">
	<p>সচিব, কারিগরি ও মাদরাসা শিক্ষা বিভাগ, শিক্ষা মন্ত্রণালয়</p>
	
	
	</h5>
<p class="imgcenterofficehead">	
	<img src="//bteb.gov.bd/sites/default/files/files/bteb.portal.gov.bd/office_head/c681df77_d680_4be0_b0f5_559d45ddaf0a/Photo Kabir Sir (1).jpg" alt="" width="100" height=""/></p>
	<p>ড. খ ম কবিরুল ইসলাম</p>

<p>&nbsp;</p>

	<p>
		<a href="/site/office_head/a0039c37-ce2a-40f7-b15c-07507c17c98e/বিস্তারিত">বিস্তারিত</a>	</p>
</div>
<div class="column block">
	<h5 class="bk-org title">
	<p>চেয়ারম্যান,&nbsp;বাংলাদেশ কারিগরি শিক্ষা বোর্ড</p>
	
	
	</h5>
<p class="imgcenterofficehead">	
	<img src="//bteb.gov.bd/sites/default/files/files/bteb.portal.gov.bd/office_head/f5018b0a_e932_46d5_b64f_b56b0880d219/Ruhul-Amin.jpeg" alt="" width="100" height=""/></p>
	<p>প্রকৌশলী মোঃ রুহুল আমিন</p>

	<p>
		<a href="/site/office_head/5fcb4a3b-3013-4cce-9023-aef8ebbaee14/বিস্তারিত">বিস্তারিত</a>	</p>
</div>
<div class="column block">
	<h5 class="bk-org title">
	<p>সচিব (উপসচিব), বাংলাদেশ কারিগরি শিক্ষা বোর্ড</p>
	
	
	</h5>
<p class="imgcenterofficehead">	
	<img src="//bteb.gov.bd/sites/default/files/files/bteb.portal.gov.bd/office_head/0237bfdd_a885_4859_99b4_127d13531ae2/al-masud-karim.jpg" alt="" width="100" height=""/></p>
	<p>জনাব মোঃ আল মাসুদ করিম</p>

	<p>
		<a href="/site/office_head/fa5da682-1a1b-4f03-891c-91218b45b7aa/বিস্তারিত">বিস্তারিত</a>	</p>
</div>
<style>.column.block a{
text-decoration:underline;
}

#right-content img {
    margin-right: 20px;
}

.imgcenterofficehead {
	padding-left: 50px;
}</style><script></script><!-- <div class="column block">
    <h5 class="bk-org title">প্রকাশনাঃ বদলে যাওয়া দৃশ্যপট </h5>

    <p style="text-align:center">
        <a href="https://bangladesh.gov.bd/sites/default/files/files/bangladesh.gov.bd/files/bf4d64c5_4154_4bd2_99d5_45417fcea069/changing_scenario_September.pdf"
            title=""><img alt="বদলে যাওয়া দৃশ্যপট"
                src="https://bangladesh.gov.bd/sites/default/files/files/bangladesh.gov.bd/files/bf4d64c5_4154_4bd2_99d5_45417fcea069/A%20Changing%20Scenario.png"
                style="height:280px; width:100%">
        </a>
    </p>
</div> -->

<div class="column block">
    <h5 class="bk-org title internal-eservice">
        <a>অভ্যন্তরীণ ই-সেবাসমূহ</a>
    </h5>

                    <ul>
            
                <li>
                    <a href="https://mail.bteb.gov.bd/">ওয়েব মেইল</a>                </li>
                    </ul>
        <a href="/site/view/internal_eservices" class="btn" style="display:block;text-align:center;">সকল</a>
        
    <h5 class="bk-org title internal-mygov" onclick="window.open('https://www.mygov.bd/')"></h5>
    <h5 class="bk-org title internal-eservice-mygov" onClick="myGovServiceLink()">
                            <a id="link_service" style="color:white !important;font-size: 13px !important;"></a>
        
    </h5>
    
</div>
<style>
    .block h5.internal-eservice-mygov {
        background-image: url('sites/default/files/files/bmeb.portal.gov.bd/page/f35745b2_55a9_4633_afe5_a2ccd180add8/internal_eservice2.gif');
        background-repeat: round;
        background-color: white !important;
        font-size: 1.2em;
        margin-top: 10px;
        cursor: pointer;
        height: 50px;
        line-height: 56px;
        padding: 0 0 0 10px !important;
    }

    .block h5.internal-mygov {
        background-image: url('/sites/default/files/files/bmeb.portal.gov.bd/page/f35745b2_55a9_4633_afe5_a2ccd180add8/National-portal_bn.gif');
        background-repeat: round;
        background-color: white !important;
        cursor: pointer;
        margin-top: 10px;
        font-size: 1.2em;
        height: 50px;
        line-height: 56px;
        padding: 0 0 0 10px !important;
    }

    .block h5.internal-eservice {
        //background-image: url('/sites/default/files/files/pmo.portal.gov.bd/page/761f04a2_c625_480e_96cc_b9a0c006d5c3/internal_eservice2.png');
        //background-repeat: round;
        //background-color: white !important;

        font-size: 1.2em;

        height: 50px;
        line-height: 56px;
        padding: 0 0 0 10px !important;
    }

    .block h5.internal-eservice a {

        color: white !important;
        display: block;
        text-decoration: none;
    }

    @media only screen and (max-width: 979px) and (min-width: 320px) {

        .block h5.internal-eservice a {

            margin-top: 15px;
            font-size: 17px;
        }

    }
</style>
<script>
    function myGovServiceLink() {
        const data = "bteb.gov.bd";
        const domain = document.getElementById("link_service").href = "https://www.mygov.bd/serviceByOffice/?agent=np&domain=" + data;
        window.open(domain);
        return false;
    }
</script><a href="//bangladesh.gov.bd/site/view/all_eservices_in_bangladesh/">
  <div class="column block central-eservices">
    <h5 class="bk-org title eservice-title">কেন্দ্রীয় ই-সেবা</h5>
  </div>
</a>

<!-- <div class="column block central-eservices">
  <h5 class="bk-org title eservice-title">কেন্দ্রীয় ই-সেবা
  </h5>
        <ul>
        
        
        <li class="item_"></li>
              
        
        <li class="item_"></li>
              
        
        <li class="item_"></li>
              
        
        <li class="item_"></li>
              
        
        <li class="item_"></li>
              
        
        <li class="item_"></li>
              
        
        <li class="item_"></li>
              
        
        <li class="item_"></li>
              
        
        <li class="item_"></li>
              
        
        <li class="item_"></li>
              
        
        <li class="item_"></li>
              
        
        <li class="item_"></li>
              
        
        <li class="item_"></li>
                </ul>
          <a href="" class="btn" style="display:block;text-align:center;">সকল</a>
      </div>
 --><style>.eservice-title {
    background-color: #609513 !important;
    color: #fff;
    font-size: 12px;
    padding: 5px;
}
.block ul li {
  background: rgba(0, 0, 0, 0) url("/themes/responsive_npf/images/bg_block_list.png") no-repeat scroll center bottom;
  font-size: 120%;
  height: auto;
  list-style-type: none;
  margin-bottom: 5px;
  padding-bottom: 8px;
  padding-left: 32px;
  padding-top: 0;
}

body.bpsc-portal-gov-bd .wsis_prize{display:none}</style><script></script>
<div class="column block">
	<h5 class="bk-org title">গুরুত্বপূর্ণ লিংক
	</h5>
				<ul>
				
				<li><a href="http://www.bangladesh.gov.bd/">গণপ্রজাতন্ত্রী বাংলাদেশ সরকার</a></li>
				
				<li><a href="https://bteb.gov.bd/site/page/b10d1d47-1f07-4815-bf41-5a90dd36358e">জাতীয় সংগীত</a></li>
				
				<li><a href="http://www.moedu.gov.bd/">শিক্ষা মন্ত্রণালয়</a></li>
				
				<li><a href="http://www.educationboard.gov.bd/">আন্ত: শিক্ষা বোর্ড</a></li>
				
				<li><a href="https://tmed.gov.bd/">কারিগরি ও মাদ্রাসা শিক্ষা বিভাগ</a></li>
				
				<li><a href="https://techedu.gov.bd">কারিগরি শিক্ষা অধিদপ্তর</a></li>
				
				<li><a href="http://www.banbeis.gov.bd/">বেনবেইস</a></li>
					</ul>
	<a href="/site/view/important_links" class="btn" style="display:block;text-align:center;">সকল লিংক</a>
	</div>
<style></style><script></script><!-- discount_electronic_toll_lanes_bridges -->
    <div class="column block">
        <a href="https://bkkb.portal.gov.bd/" target="_blank" title="">
             <img src="https://ictd.portal.gov.bd/uploader/server/../../sites/default/files/files/ictd.portal.gov.bd/npfblock/6c9cad15_7fa7_4419_b4d5_b3b21dc228a5/bkkb_button_bn.png" style="width:100%">
        </a>
    </div>
<style>
  
</style>
<script>
  
</script>
<div class="column block">
	<h5 class="bk-org title">ইনোভেশন কর্নার
	</h5>
	</div>
<style></style><script></script><!-- office_attachment_application_form -->
    <div class="column block">
        <a href="http://npftr.portal.gov.bd/new-domain" title="সরকারি অফিসের নতুন ওয়েবসাইটের আবেদন">
            <div class="column block central-eservices">
                <h5 class="bk-org title eservice-title">সরকারি অফিসের নতুন ওয়েবসাইটের আবেদন</h5>
            </div>
        </a>
    </div>
<div class="column block">
	<h5 class="bk-org title">
  জরুরি হটলাইন 
  </h5>
  <p><img alt="" src="/sites/default/files/files/admin.portal.gov.bd/npfblock//National-Helpline%20%281%29.jpg" style="height:100%; width:220px" /></p>
<p>
    </p>
</div>
<style>#right-content .block { display:block !important}</style><script></script>                <!-- <div style="" class="column block">

                        <h5 style="background-color: #eee;">
                                                                                                            দর্শক সংখ্যাঃ
                                                <span style="padding:5px; background-color: #609513; color: #fff; font-weight:bold;">
                                                    <span>
                        </h5>
                    </div> -->
                            </div>
        </div>
    </div>
    <!-- container -->


    <div class="footer-artwork" id="footer-artwork">&nbsp;</div>
	<div class="footer-wrapper full-width" id="footer-wrapper">
		<div id="footer-menu">

        <ul><li><a href="/site/office/e39bf135-1850-4434-a1a5-20041e636dad/ম্যাপ">ম্যাপ</a></li><li><a href="/site/view/sitemap//সাইটম্যাপ">সাইটম্যাপ</a></li><li><a href="https://bteb.portal.gov.bd/site/page/1e71c906-bbfc-43e2-bda1-f4f436b03110">প্রতিষ্ঠানের তালিকা</a></li><li><a href="http://bteb.portal.gov.bd/site/page/859b6dd7-7566-48b5-8e2f-19daa43cb103">আমাদের সার্ভিস সমূহ</a></li></ul>                    <div style="float: left; font-size: .9em;">
				সাইটটি শেষ হাল-নাগাদ করা হয়েছে: <span style="font-style: italic;">&#x09E8;&#x09E6;&#x09E8;&#x09EB;-&#x09E6;&#x09EC;-&#x09E8;&#x09E8; &#x09E7;&#x09EA;:&#x09E8;&#x09E9;:&#x09E7;&#x09E9;</span>
				<!--<span><a href="http://support.portal.gov.bd/" style="color: green" target="_blank"> | <u>হেল্পডেস্ক</u></a></span>-->
			</div>
            </div>

		<div class="footer-credit" id="footer">
        <!--  -->
        
            <p>
                পরিকল্পনা ও বাস্তবায়নে:&nbsp;
                <a href="http://www.cabinet.gov.bd/">মন্ত্রিপরিষদ
                    বিভাগ</a>,&nbsp;
                <a href="https://a2i.gov.bd">এটুআই</a>,&nbsp;
                <a href="http://www.bcc.net.bd/">বিসিসি</a>,&nbsp;
                <a href="http://doict.gov.bd/">ডিওআইসিটি</a>&nbsp;ও&nbsp;
                <a href="http://www.basis.org.bd/">বেসিস</a>।
            </p>

            <!-- <p>
                কারিগরি সহায়তায়:<a href="https://a2i.gov.bd"><img
                    style=""
                    src="/themes/responsive_npf/img/a2i.png"
                    alt=""></a>
            </p> -->

            <p>
               কারিগরি সহায়তায়:
                   <img style="vertical-align: baseline;" src="/themes/responsive_npf/img/np-logo-set.png" alt="">
            </p>
            




        </div>
		<!-- /footer -->
	</div>


    ﻿<script>


        function setLanguageCookie(cookieValue) {
            var today = new Date();
            var expire = new Date();
            var cookieName = 'lang';
            //var cookieValue = "bn";
            var nDays = 5;
            expire.setTime(today.getTime() + 3600000 * 24 * nDays);
            document.cookie = cookieName + "=" + escape(cookieValue)
                + ";expires=" + expire.toGMTString();
        }

        function setLanguage() {
            $("#lang_form").submit();
            return false;
        }
       
        $(function () {

            // Slideshow 4
            $("#front-image-slider").responsiveSlides({
                auto: true,
                pager: false,
                nav: true,
                speed: 2000,
                maxwidth: 960,
                namespace: "callbacks"
            });
            $("#right-content a").click(function () {
                var url = $(this).attr('href');
                if (isExternal(url) && url != 'javascript:;') {
                    openInNewTab(url);
                    return false;
                }
            });
        });
        function openInNewTab(url) {
            var win = window.open(url, '_blank');
            win.focus();
        }
        function isExternal(url) {
            var match = url.match(/^([^:\/?#]+:)?(?:\/\/([^\/?#]*))?([^?#]+)?(\?[^#]*)?(#.*)?/);
            if (typeof match[1] === "string" && match[1].length > 0 && match[1].toLowerCase() !== location.protocol)
                return true;
            if (typeof match[2] === "string" && match[2].length > 0 && match[2].replace(new RegExp(":(" + {
                        "http:": 80,
                        "https:": 443
                    }[location.protocol] + ")?$"), "") !== location.host)
                return true;
            return false;
        }
    </script>



<script>
    $(function () {


        function initNewsTicker(id, options) {

            var $scroller = $(id);
            $scroller.vTicker('init', options);

            $("#news-ticker .next").click(function (event) {
                event.preventDefault();
                var checked = true;
                $('#news-ticker').vTicker('next', {animate: checked});
            });
            $("#news-ticker .prev,#news-ticker .next").hover(function () {
                $('#news-ticker').vTicker('next', {animate: checked});
                $scroller.vTicker('pause', true);
            }, function () {
                $('#news-ticker').vTicker('next', {animate: checked});
                $scroller.vTicker('pause', false);
            });
            $("#news-ticker .prev").click(function (event) {
                event.preventDefault();
                var checked = true;
                $('#news-ticker').vTicker('prev', {animate: checked});
            });
        }

        function initNoticeBoardTicker(id, options) {

            var $scroller = $(id);
            $scroller.vTicker('init', options);

            $("#notice-board-ticker .next").click(function (event) {
                event.preventDefault();
                var checked = true;
                $('#notice-board-ticker').vTicker('next', {animate: false});
            });
            $("#notice-board-ticker .prev,#notice-board-ticker .next").hover(function () {
                $scroller.vTicker('pause', true);
            }, function () {
                $scroller.vTicker('pause', false);
            });
            $("#notice-board-ticker .prev").click(function (event) {
                event.preventDefault();
                var checked = true;
                $('#notice-board-ticker').vTicker('prev', {animate: checked});
            });
        }

        initNewsTicker('#news-ticker', {});
        //initNoticeBoardTicker('#notice-board-ticker', {showItems:10, margin: 0, padding: 0,animate:false});


    });


    /* Responsive Menu*/


</script>

	
		<!-- Matomo -->
		<script type="text/javascript">
		  var _paq = _paq || [];
		  /* tracker methods like "setCustomDimension" should be called before "trackPageView" */
		  _paq.push(['trackPageView']);
		  _paq.push(['enableLinkTracking']);
		  (function() {
			var u="https://analytics.portal.gov.bd/piwik/";
			_paq.push(['setTrackerUrl', u+'piwik.php']);
			_paq.push(['setSiteId', 158]);
			var d=document, g=d.createElement('script'), s=d.getElementsByTagName('script')[0];
			g.type='text/javascript'; g.async=true; g.defer=true; g.src=u+'piwik.js'; s.parentNode.insertBefore(g,s);
		  })();
		</script>
	<!-- End Matomo Code -->


<script>
    $(".meganizr .mzr-drop").keyup(function () {

        $(".mzr-content").attr("aria-hidden", "true");
        $(this).find(".mzr-content").attr("aria-hidden", "false");
    });
    // ============ start tile for <a> and alt for img ========
    $('a').each(function () {
        $(this).attr('title', $(this).text());
    });

    var lan = "bn";
    if (lan == 'en') {
        $('.mzr-drop a:first-child').each(function () {
            $(this).attr('title', "Enter to get more menu");
        });
    } else {
        $('.mzr-drop a:first-child').each(function () {
            $(this).attr('title', "সাবমেনুর জন্য ক্লিক করুন");
        });
    }
    $('img').each(function () {
        var str = $(this).attr("src");
        var arr = str.split('/');
        var strFine = arr[arr.length - 1];

        var str2 = strFine;
        var arr2 = str2.split('.');
        var strFine2 = arr2[arr2.length - 2];
        $(this).attr('alt', strFine2);
    });
    $('a2iLogo').attr('alt', 'Access to information');
    $('.service-box img').each(function () {
        var strTitle = $(this).parent().find('h4').text();
        $(this).attr('alt', strTitle);
    });
    $('.block img').each(function () {
        var strTitleRight = $(this).closest('.block').find('.title').text();
        $(this).attr('alt', strTitleRight);
    });
    $('#notice-board-ticker .btn').attr('title', 'সকল নোটিশ');
    $('#news-ticker .btn').attr('title', 'সকল খবর');
    $('#search').each(function () {
        $(this).attr('alt', 'Search');
    });
    $('.search-btn').each(function () {
        $(this).attr('alt', 'Enter to search');
    });
    $(".mzr-content").mouseout(function () {
        $(this).hide();
    });
    $(".submenu").mouseover(function () {
        $(this).siblings('.mzr-content').show();
    });
    $(".mzr-content").mouseover(function () {
        $(this).show();
    });
    // ============ end tile for <a> and alt for img ========
</script>

<script>
    $(document).ready(function () {
        $(".slide-panel-button").click(function () {
            $('#domain-selector-panel').toggle()//animate({height: "toggle"}, 200);
            if ($('#domain-selector-panel').is(":visible")) {
                $('#div-lang').css('z-index', '200');
            } else {
                $('#div-lang').css('z-index', '1001');
            }
            $(".slide-panel-button").toggle();
        });

    });
</script>





 <!-- ============ start accessibility megamenu ============ -->

 	<script>

        $(document).ready(function ($) {


            $("#dawgdrops").accessibleMegaMenu({
                /* prefix for generated unique id attributes, which are required
                 to indicate aria-owns, aria-controls and aria-labelledby */
                uuidPrefix: "accessible-megamenu",

                /* css class used to define the megamenu styling */
                menuClass: "meganizr",

                /* css class for a top-level navigation item in the megamenu */
                topNavItemClass: "mzr-drop",

                /* css class for a megamenu panel */
                panelClass: "mzr-content",

                /* css class for a group of items within a megamenu panel */
                panelGroupClass: "mzr-links",

                /* css class for the hover state */
                hoverClass: "hover",

                /* css class for the focus state */
                focusClass: "focus-content",

                /* css class for the open state */
                openClass: "open hover-content"
            });

        });
    </script>


<script>

    $(document).ready(function () {
        var wi = $(window).width();
        if (wi < 769) {
            $('#printable_area td').removeAttr('style');
            $('#printable_area td p').css("width", "100%");
        }
    });
    $( ".meganizr .mzr-drop").keyup(function() {

		$(".mzr-content").attr("aria-hidden","true");
		$(this).find(".mzr-content").attr("aria-hidden", "false");
	});
    // ============ start tile for <a> and alt for img ========
    $('a').each(function() {
        $(this).attr('title', $(this).text());
    });

    var lan = "bn";
    if(lan == 'en'){
        $('.mzr-drop a:first-child').each(function() {
                $(this).attr('title', "Enter to get more menu");
        });
    }else{
        $('.mzr-drop a:first-child').each(function() {
                $(this).attr('title', "সাবমেনুর জন্য ক্লিক করুন");
        });
    }
    $('img').each(function() {
        var str = $(this).attr("src");
        var arr = str.split('/');
        var strFine = arr[arr.length-1];

        var str2 = strFine;
        var arr2 = str2.split('.');
        var strFine2 = arr2[arr2.length-2];
        $(this).attr('alt', strFine2);
    });
    $('a2iLogo').attr('alt', 'Access to information');
    $('.service-box img').each(function() {
        var strTitle = $(this).parent().find('h4').text();
        $(this).attr('alt', strTitle);
    });
    $('.block img').each(function() {
        var strTitleRight = $(this).closest('.block').find('.title').text();
        $(this).attr('alt', strTitleRight);
    });
    $('#notice-board-ticker .btn').attr('title', 'সকল নোটিশ');
    $('#news-ticker .btn').attr('title', 'সকল খবর');
    $('#search').each(function() {
        $(this).attr('alt', 'Search');
    });
    $('.search-btn').each(function() {
        $(this).attr('alt', 'Enter to search');
    });
    // ============ end tile for <a> and alt for img ========

    // =============== start dropdown design =======
    $(".mzr-content").mouseout(function(){
       // $(this).hide();
    });
    $(".submenu").mouseover(function(){
        //$('.mzr-content').show();
    });
    $(".mzr-content").mouseover(function(){
        //$(this).show();
    });
    // =============== End dropdown design =======

</script>




</body>

</html><!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=G-XL3REV1DHW"></script>
<script>
    window.dataLayer = window.dataLayer || [];
    function gtag(){dataLayer.push(arguments);}
        gtag('js', new Date());

        gtag('config', 'G-XL3REV1DHW');
        gtag('event', 'bteb.gov.bd (Frontend)', {
            'event_category' : 'Frontend'
    });
</script>
