<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  
  <title>My website</title>
</head>
<body>

   <div class="site-wrapper">
   
  <div class="container"> 
   <?php include 'includes/top header bar.php';?>
  <?php include 'includes/banner slider.php';?>
  
  
  <?php include 'includes/nav-bar.php';?>
    <div class="main-content">
	<?php include 'includes/header.php';?>
    </div>
	<div class="right-side-bar">
      <?php include 'includes/sidebar.php'; ?>
    </div>
  </div>
  <?php include 'includes/footer.php'; ?>
  </div>
</body>
</html>